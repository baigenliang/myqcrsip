package com.rsvmcs.qcrsip.entity;


import java.io.IOException;
import java.util.List;

public interface SipProvider {
    void addSipListener(SipListener l);
    void removeSipListener(SipListener l);
    SipListener getSipListener();

    void sendRequest(Request request) throws IOException;
    void sendResponse(Response response) throws IOException;

    void addListeningPoint(ListeningPoint lp) throws IOException;
    void removeListeningPoint(ListeningPoint lp) throws IOException;
    List<ListeningPoint> getListeningPoints();
}