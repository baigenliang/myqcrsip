package com.rsvmcs.qcrsip.entity;


public class StatusLine {
    private final String version;
    private final int statusCode;
    private final String reason;
    public StatusLine(String version, int statusCode, String reason) {
        this.version = version; this.statusCode = statusCode; this.reason = reason;
    }
    public String getVersion(){ return version; }
    public int getStatusCode(){ return statusCode; }
    public String getReasonPhrase(){ return reason; }
    public String encode(){ return version + " " + statusCode + " " + reason; }
    public static StatusLine parse(String line){
        String[] p = line.split(" ",3);
        int code = -1;
        try { if (p.length>1) code = Integer.parseInt(p[1]); } catch(Exception ignored){}
        return new StatusLine(p.length>0?p[0]:"", code, p.length>2?p[2]:"");
    }
    @Override public String toString(){ return encode(); }
}
