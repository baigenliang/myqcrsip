package com.rsvmcs.qcrsip.entity;


public interface Response {
    StatusLine getStatusLine();
    String getHeader(String name);
    void setHeader(String name, String value);
    byte[] getRawContent();
    void setRawContent(byte[] data);

    String getDestinationHost();
    int getDestinationPort();
    Request.Transport getTransport();
    void setDestination(String host, int port, Request.Transport t);
}