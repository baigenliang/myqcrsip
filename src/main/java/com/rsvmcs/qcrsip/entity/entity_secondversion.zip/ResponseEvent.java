package com.rsvmcs.qcrsip.entity;


import java.net.InetAddress;
import java.util.EventObject;

public class ResponseEvent extends EventObject {
    private final SipResponse response;
    private final InetAddress remoteAddress;
    private final int remotePort;
    private final ListeningPoint.Transport transport;

    public ResponseEvent(Object src, SipResponse resp, InetAddress addr, int port, ListeningPoint.Transport t) {
        super(src); this.response = resp; this.remoteAddress = addr; this.remotePort = port; this.transport = t;
    }
    public SipResponse getResponse(){ return response; }
    public InetAddress getRemoteAddress(){ return remoteAddress; }
    public int getRemotePort(){ return remotePort; }
    public ListeningPoint.Transport getTransport(){ return transport; }
}