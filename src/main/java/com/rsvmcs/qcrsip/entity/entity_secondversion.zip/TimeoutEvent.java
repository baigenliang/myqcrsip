package com.rsvmcs.qcrsip.entity;

import java.util.EventObject;


public class  TimeoutEvent extends EventObject {
    private final String transactionKey;
    public TimeoutEvent(Object src, String transactionKey) {
        super(src);
        this.transactionKey = transactionKey;
    }
    public String getTransactionKey() { return transactionKey; }
}