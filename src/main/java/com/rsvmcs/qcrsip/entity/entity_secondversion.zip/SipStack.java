package com.rsvmcs.qcrsip.entity;

public interface SipStack {
    ListeningPoint createListeningPoint(String ip, int port, ListeningPoint.Transport transport);
    SipProvider createSipProvider(ListeningPoint lp) throws Exception;
}