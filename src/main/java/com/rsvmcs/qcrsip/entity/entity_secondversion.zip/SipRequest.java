package com.rsvmcs.qcrsip.entity;


public class SipRequest extends SIPMessage implements Request {
    private final RequestLine requestLine;
    private String destHost; private int destPort; private Request.Transport destTransport = Request.Transport.UDP;

    public SipRequest(RequestLine rl) {
        this.requestLine = rl;
        this.startLine = rl.encode();
    }

    @Override public RequestLine getRequestLine(){ return requestLine; }
    @Override public String getHeader(String name){ return headers.get(name); }
    @Override public void setHeader(String name, String value){ headers.put(name,value); }
    @Override public byte[] getRawContent(){ return body; }
    @Override public void setRawContent(byte[] data){ body = data; }
    @Override public String getDestinationHost(){ return destHost; }
    @Override public int getDestinationPort(){ return destPort; }
    @Override public Request.Transport getTransport(){ return destTransport; }
    @Override public void setDestination(String host, int port, Request.Transport t){
        this.destHost = host; this.destPort = port; this.destTransport = t;
    }
}
