package com.rsvmcs.qcrsip.entity;

public class RequestLine {
    private final String method;
    private final String uri;
    private final String version;

    public RequestLine(String method, String uri, String version) {
        this.method = method; this.uri = uri; this.version = version;
    }
    public String getMethod(){ return method; }
    public String getUri(){ return uri; }
    public String getVersion(){ return version; }
    public String encode(){ return method + " " + uri + " " + version; }
    public static RequestLine parse(String line) {
        String[] p = line.split(" ",3);
        return new RequestLine(p.length>0?p[0]:"", p.length>1?p[1]:"", p.length>2?p[2]:"");
    }
    @Override public String toString(){ return encode(); }
}
