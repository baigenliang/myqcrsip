package com.rsvmcs.qcrsip.entity;


public interface Request {
    RequestLine getRequestLine();
    String getHeader(String name);
    void setHeader(String name, String value);
    byte[] getRawContent();
    void setRawContent(byte[] data);

    String getDestinationHost();
    int getDestinationPort();
    Transport getTransport();
    void setDestination(String host, int port, Transport t);

    enum Transport { UDP, TCP }
}