package com.rsvmcs.qcrsip.entity;


public class ListeningPoint {
    public enum Transport { TCP, UDP }
    private final String ip;
    private final int port;
    private final Transport transport;

    public ListeningPoint(String ip, int port, Transport transport) {
        this.ip = ip; this.port = port; this.transport = transport;
    }
    public String getIp(){ return ip; }
    public int getPort(){ return port; }
    public Transport getTransport(){ return transport; }
    public String key(){ return ip + ":" + port + ":" + transport.name(); }
}