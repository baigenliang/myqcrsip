package com.rsvmcs.qcrsip.entity;


import java.net.InetAddress;
import java.util.EventObject;

/**
 * 不持有 Socket，只有来源地址/端口/transport
 */
public class RequestEvent extends EventObject {
    private final SipRequest request;
    private final InetAddress remoteAddress;
    private final int remotePort;
    private final ListeningPoint.Transport transport;

    public RequestEvent(Object src, SipRequest req, InetAddress addr, int port, ListeningPoint.Transport t) {
        super(src); this.request = req; this.remoteAddress = addr; this.remotePort = port; this.transport = t;
    }
    public SipRequest getRequest(){ return request; }
    public InetAddress getRemoteAddress(){ return remoteAddress; }
    public int getRemotePort(){ return remotePort; }
    public ListeningPoint.Transport getTransport(){ return transport; }
}