package com.rsvmcs.qcrsip.entity;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 基本的 SIP 消息序列化/反序列化（GB2312 body）
 */
public abstract class SIPMessage {
    public static final Charset GB2312 = Charset.forName("GB2312");
    public static final String CRLF = "\r\n";

    protected String startLine;
    protected final LinkedHashMap<String,String> headers = new LinkedHashMap<>();
    protected byte[] body;

    public String getHeader(String name) { return headers.get(name); }
    public void setHeader(String name, String value) { headers.put(name, value); }
    public Map<String,String> getAllHeaders() { return headers; }
    public byte[] getRawContent() { return body; }
    public void setRawContent(byte[] data) { body = data; }

    public byte[] toBytes() {
        try {
            byte[] bodyBytes = body == null ? new byte[0] : body;
            LinkedHashMap<String,String> tmp = new LinkedHashMap<>(headers);
            tmp.put("Content-Length", String.valueOf(bodyBytes.length));
            StringBuilder sb = new StringBuilder();
            sb.append(startLine).append(CRLF);
            for (Map.Entry<String,String> e : tmp.entrySet()) {
                sb.append(e.getKey()).append(": ").append(e.getValue()).append(CRLF);
            }
            sb.append(CRLF);
            byte[] head = sb.toString().getBytes(StandardCharsets.US_ASCII);
            byte[] out = new byte[head.length + bodyBytes.length];
            System.arraycopy(head,0,out,0,head.length);
            System.arraycopy(bodyBytes,0,out,head.length,bodyBytes.length);
            return out;
        } catch(Exception ex) { throw new RuntimeException(ex); }
    }

    @Override
    public String toString() {
        try { return new String(toBytes(), GB2312); }
        catch(Exception e) { return startLine + " " + headers.toString(); }
    }

    // Parse raw bytes into SipRequest or SipResponse
    public static SIPMessage parse(byte[] raw) throws Exception {
        int sep = -1;
        for (int i=0;i<raw.length-3;i++) {
            if (raw[i]==13 && raw[i+1]==10 && raw[i+2]==13 && raw[i+3]==10) { sep=i; break; }
        }
        if (sep == -1) throw new IllegalArgumentException("Invalid SIP message: no header/body separator");
        String headerPart = new String(raw,0,sep, StandardCharsets.US_ASCII);
        String[] lines = headerPart.split("\\r\\n");
        String first = lines[0].trim();
        LinkedHashMap<String,String> hdrs = new LinkedHashMap<>();
        for (int i=1;i<lines.length;i++) {
            String l = lines[i];
            int idx = l.indexOf(':');
            if (idx>0) hdrs.put(l.substring(0,idx).trim(), l.substring(idx+1).trim());
        }
        int contentLength = 0;
        String cl = hdrs.get("Content-Length");
        if (cl != null) {
            try { contentLength = Integer.parseInt(cl.trim()); } catch(Exception ignored){}
        } else {
            contentLength = raw.length - (sep + 4);
        }
        byte[] body = new byte[contentLength];
        if (contentLength>0) System.arraycopy(raw,sep+4,body,0,contentLength);
        if (first.startsWith("SIP/2.0")) {
            StatusLine sl = StatusLine.parse(first);
            SipResponse r = new SipResponse(sl);
            r.headers.putAll(hdrs);
            r.body = body;
            return r;
        } else {
            RequestLine rl = RequestLine.parse(first);
            SipRequest req = new SipRequest(rl);
            req.headers.putAll(hdrs);
            req.body = body;
            return req;
        }
    }
}