package com.rsvmcs.qcrsip.core;


import com.rsvmcs.qcrsip.entity.RequestEvent;
import com.rsvmcs.qcrsip.entity.ResponseEvent;
import com.rsvmcs.qcrsip.entity.SipListener;
import com.rsvmcs.qcrsip.entity.TimeoutEvent;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import java.io.IOException;
import java.net.*;
import java.nio.*;
import java.nio.channels.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.BiConsumer;

/**
 * 单一线程事件调度器，把事件发送给 SipListener
 */
public class EventScanner implements Runnable {
    private final BlockingQueue<EventWrapper> q = new LinkedBlockingQueue<>();
    private volatile boolean running = true;
    private SipListener listener;

    public EventScanner(SipListener listener) { this.listener = listener; }

    public void addEvent(EventWrapper ev){ q.offer(ev); }
    public void stop(){ running = false; }

    @Override
    public void run() {
        while (running) {
            try {
                EventWrapper ew =   q.take();
                switch (ew.getType()) {
                    case REQUEST:
                        listener.processRequest((RequestEvent)ew.getEvent());
                        break;
                    case RESPONSE:
                        listener.processResponse((ResponseEvent)ew.getEvent());
                        break;
                    case TIMEOUT:
                        listener.processTimeout((TimeoutEvent)ew.getEvent());
                        break;
                    default:
                        break;
                }
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }
    }
}
