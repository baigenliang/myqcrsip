package com.rsvmcs.qcrsip.core;


import com.rsvmcs.qcrsip.entity.*;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * 使用 ConnectionManager 进行 TCP 发包（异步），UDP 用 DatagramSocket。
 * deliverRawMessage 会被 SipStackImpl 的监听线程调用，把 raw bytes 解析并放入 EventScanner。
 */
public class SipProviderImpl implements SipProvider {
    private final Map<String, ListeningPoint> listeningPoints = new ConcurrentHashMap<>();
    private final CopyOnWriteArrayList<SipListener> listeners = new CopyOnWriteArrayList<>();
    private final EventScanner eventScanner;
    private final ConnectionManager connManager;
    private final ExecutorService executor = Executors.newCachedThreadPool();

    // transaction mapping: use CSeq only as requested
    private final ConcurrentMap<String, InetSocketAddress> udpMap = new ConcurrentHashMap<>();
    // connManager keeps TCP connections, mapping not needed; we still keep transaction->remote to help fallback
    private final ConcurrentMap<String, String> tcpMap = new ConcurrentHashMap<>(); // cseq -> host:port

    public SipProviderImpl(EventScanner scanner) throws IOException {
        this.eventScanner = scanner;
        this.connManager = new ConnectionManager(this::onTcpIncoming);
    }

    // called by ConnectionManager when bytes arrive: remoteKey like host:port
    private void onTcpIncoming(String remoteKey, byte[] raw) {
        try {
            SIPMessage msg = SIPMessage.parse(raw);
            if (msg instanceof SipRequest) {
                SipRequest req = (SipRequest) msg;
                String cseq = extractCSeq(req.getHeader("CSeq"));
                if (cseq != null) tcpMap.put(cseq, remoteKey);
                String[] hp = remoteKey.split(":");
                InetAddress addr = InetAddress.getByName(hp[0]);
                int port = Integer.parseInt(hp[1]);
                RequestEvent ev = new RequestEvent(this, req, addr, port, ListeningPoint.Transport.TCP);
                eventScanner.addEvent(new EventWrapper(EventWrapper.Type.REQUEST, ev));
            } else if (msg instanceof SipResponse) {
                SipResponse resp = (SipResponse) msg;
                String cseq = extractCSeq(resp.getHeader("CSeq"));
                String[] hp = remoteKey.split(":");
                InetAddress addr = InetAddress.getByName(hp[0]);
                int port = Integer.parseInt(hp[1]);
                ResponseEvent ev = new ResponseEvent(this, resp, addr, port, ListeningPoint.Transport.TCP);
                eventScanner.addEvent(new EventWrapper(EventWrapper.Type.RESPONSE, ev));
            }
        } catch (Exception ex) { ex.printStackTrace(); }
    }

    @Override public void addSipListener(SipListener l){ listeners.add(l); }
    @Override public void removeSipListener(SipListener l){ listeners.remove(l); }
    @Override public SipListener getSipListener(){ return listeners.isEmpty()?null:listeners.get(0); }

    @Override
    public void sendRequest(Request request) throws IOException {
        byte[] data = (request instanceof SIPMessage) ? ((SIPMessage)request).toBytes() : request.toString().getBytes(SIPMessage.GB2312);
        if (request.getTransport() == Request.Transport.TCP) {
            connManager.sendAsync(request.getDestinationHost(), request.getDestinationPort(), data);
            // store mapping cseq->remote for response routing
            String cseq = extractCSeq(request.getHeader("CSeq"));
            if (cseq != null) tcpMap.put(cseq, request.getDestinationHost()+":"+request.getDestinationPort());
        } else {
            try (DatagramSocket ds = new DatagramSocket()) {
                DatagramPacket p = new DatagramPacket(data, data.length,
                        InetAddress.getByName(request.getDestinationHost()), request.getDestinationPort());
                ds.send(p);
                // map for response matching
                String cseq = extractCSeq(request.getHeader("CSeq"));
                if (cseq != null) udpMap.put(cseq, new InetSocketAddress(request.getDestinationHost(), request.getDestinationPort()));
            }
        }
    }

    @Override
    public void sendResponse(Response response) throws IOException {
        byte[] data = (response instanceof SIPMessage) ? ((SIPMessage)response).toBytes() : response.toString().getBytes(SIPMessage.GB2312);
        String cseq = extractCSeq(response.getHeader("CSeq"));
        // prefer TCP mapping
        if (cseq != null) {
            String tcpRemote = tcpMap.get(cseq);
            if (tcpRemote != null) {
                String[] hp = tcpRemote.split(":");
                connManager.sendAsync(hp[0], Integer.parseInt(hp[1]), data);
                return;
            }
            InetSocketAddress up = udpMap.get(cseq);
            if (up != null) {
                try (DatagramSocket ds = new DatagramSocket()) {
                    DatagramPacket p = new DatagramPacket(data, data.length, up.getAddress(), up.getPort());
                    ds.send(p);
                    return;
                }
            }
        }
        // fallback: use response.destination
        if (response.getDestinationHost()!=null) {
            if (response.getTransport() == Request.Transport.TCP) {
                connManager.sendAsync(response.getDestinationHost(), response.getDestinationPort(), data);
            } else {
                try (DatagramSocket ds = new DatagramSocket()) {
                    DatagramPacket p = new DatagramPacket(data, data.length,
                            InetAddress.getByName(response.getDestinationHost()), response.getDestinationPort());
                    ds.send(p);
                }
            }
        } else {
            throw new IOException("No mapping for response (no CSeq mapping and no destination)");
        }
    }

    @Override
    public void addListeningPoint(ListeningPoint lp) { listeningPoints.put(lp.key(), lp); }
    @Override
    public void removeListeningPoint(ListeningPoint lp) { listeningPoints.remove(lp.key()); }
    @Override
    public List<ListeningPoint> getListeningPoints() { return new ArrayList<>(listeningPoints.values()); }

    // Called by SipStackImpl network threads when raw bytes received (UDP path)
    public void deliverRawMessage(byte[] raw, InetSocketAddress remote, ListeningPoint.Transport transport) {
        executor.submit(() -> {
            try {
                SIPMessage msg = SIPMessage.parse(raw);
                if (msg instanceof SipRequest) {
                    SipRequest req = (SipRequest) msg;
                    String cseq = extractCSeq(req.getHeader("CSeq"));
                    if (cseq != null && transport == ListeningPoint.Transport.UDP) udpMap.put(cseq, remote);
                    RequestEvent re = new RequestEvent(this, req, remote.getAddress(), remote.getPort(), transport);
                    eventScanner.addEvent(new EventWrapper(EventWrapper.Type.REQUEST, re));
                } else if (msg instanceof SipResponse) {
                    SipResponse resp = (SipResponse) msg;
                    ResponseEvent re = new ResponseEvent(this, resp, remote.getAddress(), remote.getPort(), transport);
                    eventScanner.addEvent(new EventWrapper(EventWrapper.Type.RESPONSE, re));
                }
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    private String extractCSeq(String cseqHeader) {
        if (cseqHeader == null) return null;
        String[] p = cseqHeader.trim().split(" ");
        return p.length>0 ? p[0] : cseqHeader;
    }
}