package com.rsvmcs.qcrsip.core;


import com.rsvmcs.qcrsip.entity.*;
import org.springframework.stereotype.Component;

import java.io.*;
import java.net.*;
import java.util.concurrent.*;

/**
 * createListeningPoint / createSipProvider.
 * Starts UDP server or TCP acceptor; UDP/TCP server threads call provider.deliverRawMessage / provider.connManager path.
 */

public class SipStackImpl implements SipStack {

    private final ExecutorService executor = Executors.newCachedThreadPool();

    @Override
    public ListeningPoint createListeningPoint(String ip, int port, ListeningPoint.Transport transport) {
        return new ListeningPoint(ip, port, transport);
    }

    @Override
    public SipProvider createSipProvider(ListeningPoint lp) throws Exception {
        // Create event scanner with a default no-op business listener, provider.addSipListener() later will attach real listener
        EventScanner scanner = new EventScanner(new SipListener() {
            @Override public void processRequest(RequestEvent requestEvent) {}
            @Override public void processResponse(ResponseEvent responseEvent) {}
            @Override public void processTimeout(TimeoutEvent timeoutEvent) {}
        });
        SipProviderImpl provider = new SipProviderImpl(scanner);
        provider.addListeningPoint(lp);

        // start network listeners
        if (lp.getTransport() == ListeningPoint.Transport.UDP) {
            startUdp(lp, provider);
        } else {
            startTcpAcceptor(lp, provider);
        }

        // start scanner thread
        Thread t = new Thread(scanner, "EventScanner-" + lp.key());
        t.setDaemon(true);
        t.start();

        return provider;
    }

    private void startUdp(ListeningPoint lp, SipProviderImpl provider) throws IOException {
        DatagramSocket ds = new DatagramSocket(null);
        ds.setReuseAddress(true);
        ds.bind(new InetSocketAddress(lp.getIp(), lp.getPort()));
        executor.submit(() -> {
            byte[] buf = new byte[65536];
            DatagramPacket pkt = new DatagramPacket(buf, buf.length);
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    ds.receive(pkt);
                    byte[] data = new byte[pkt.getLength()];
                    System.arraycopy(pkt.getData(), pkt.getOffset(), data, 0, pkt.getLength());
                    provider.deliverRawMessage(data, new InetSocketAddress(pkt.getAddress(), pkt.getPort()), ListeningPoint.Transport.UDP);
                } catch (IOException ioe) {
                    ioe.printStackTrace();
                    break;
                }
            }
        });
        System.out.printf("UDP listening on %s:%d%n", lp.getIp(), lp.getPort());
    }

    private void startTcpAcceptor(ListeningPoint lp, SipProviderImpl provider) throws IOException {
        ServerSocket ss = new ServerSocket();
        ss.setReuseAddress(true);
        ss.bind(new InetSocketAddress(lp.getIp(), lp.getPort()));
        executor.submit(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    Socket s = ss.accept();
                    // handle connection in separate thread; read raw frames and forward to provider.deliverRawMessage (tcp path)
                    executor.submit(() -> {
                        try (InputStream in = s.getInputStream()) {
                            ByteArrayOutputStream acc = new ByteArrayOutputStream();
                            byte[] buf = new byte[4096];
                            int read;
                            while ((read = in.read(buf)) != -1) {
                                acc.write(buf,0,read);
                                byte[] accBytes = acc.toByteArray();
                                int processed = 0;
                                while (true) {
                                    int sep = indexOfDoubleCRLF(accBytes, processed);
                                    if (sep == -1) break;
                                    String headerPart = new String(accBytes, processed, sep-processed, java.nio.charset.StandardCharsets.US_ASCII);
                                    int contentLen = 0;
                                    for (String line : headerPart.split("\\r\\n")) {
                                        if (line.toLowerCase().startsWith("content-length:")) {
                                            try { contentLen = Integer.parseInt(line.substring(line.indexOf(':')+1).trim()); } catch(Exception ignored){}
                                        }
                                    }
                                    int total = (sep - processed) + 4 + contentLen;
                                    if (accBytes.length - processed < total) break;
                                    byte[] msg = new byte[total];
                                    System.arraycopy(accBytes, processed, msg, 0, total);
                                    processed += total;
                                    provider.deliverRawMessage(msg, new InetSocketAddress(s.getInetAddress(), s.getPort()), ListeningPoint.Transport.TCP);
                                }
                                if (processed>0) {
                                    byte[] left = java.util.Arrays.copyOfRange(accBytes, processed, accBytes.length);
                                    acc.reset(); acc.write(left);
                                }
                            }
                        } catch (IOException e) {
                            // connection closed
                        }
                    });
                } catch (IOException ioe) {
                    ioe.printStackTrace();
                    break;
                }
            }
        });
        System.out.printf("TCP listening on %s:%d%n", lp.getIp(), lp.getPort());
    }

    private int indexOfDoubleCRLF(byte[] buf, int offset) {
        for (int i=offset;i<buf.length-3;i++) if (buf[i]==13&&buf[i+1]==10&&buf[i+2]==13&&buf[i+3]==10) return i+4;
        return -1;
    }
}