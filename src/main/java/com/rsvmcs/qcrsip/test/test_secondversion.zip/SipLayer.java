package com.rsvmcs.qcrsip.test;


import com.rsvmcs.qcrsip.core.SipProviderImpl;
import com.rsvmcs.qcrsip.core.SipStackImpl;
import com.rsvmcs.qcrsip.entity.ListeningPoint;
import com.rsvmcs.qcrsip.entity.SipStack;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.TooManyListenersException;
import java.util.concurrent.ConcurrentHashMap;

//@Order(5)
@Component
public class SipLayer implements CommandLineRunner {

    private final static Logger logger = LoggerFactory.getLogger(SipLayer.class);

    @Autowired
    private ISIPProcessorObserver sipProcessorObserver;


    private SipStack sipStack;

    private final Map<String, SipProviderImpl> tcpSipProviderMap = new ConcurrentHashMap<>();
    private final Map<String, SipProviderImpl> udpSipProviderMap = new ConcurrentHashMap<>();

    @Override
    public void run(String... args) throws Exception {
        sipStack=new SipStackImpl();
        String ip="10.120.5.185";int port=5061;
        addListeningPoint(ip,port);

    }

    private void addListeningPoint(String monitorIp, int port){
        try {
            ListeningPoint tcpListeningPoint = sipStack.createListeningPoint(monitorIp, port, ListeningPoint.Transport.TCP);
            SipProviderImpl tcpSipProvider = null;
            try {
                tcpSipProvider = (SipProviderImpl)sipStack.createSipProvider(tcpListeningPoint);
            } catch (Exception exception) {
                exception.printStackTrace();
            }

            tcpSipProvider.addSipListener(sipProcessorObserver);
            tcpSipProviderMap.put(monitorIp, tcpSipProvider);
            logger.info("[SIP SERVER] tcp://{}:{} 启动成功", monitorIp, port);
        } catch (Exception exception) {
            logger.error("[SIP SERVER] tcp://{}:{} SIP服务启动失败,请检查端口是否被占用或者ip是否正确"
                    , monitorIp, port);
        }

        try {
            ListeningPoint udpListeningPoint = sipStack.createListeningPoint(monitorIp, port, ListeningPoint.Transport.UDP);

            SipProviderImpl udpSipProvider = null;
            try {
                udpSipProvider = (SipProviderImpl)sipStack.createSipProvider(udpListeningPoint);
            } catch (Exception exception) {
                exception.printStackTrace();
            }
            udpSipProvider.addSipListener(sipProcessorObserver);

            udpSipProviderMap.put(monitorIp, udpSipProvider);

            logger.info("[SIP SERVER] udp://{}:{} 启动成功", monitorIp, port);
        } catch (Exception e) {
            logger.error("[SIP SERVER] udp://{}:{} SIP服务启动失败,请检查端口是否被占用或者ip是否正确"
                    , monitorIp, port);
        }
    }


}
