package com.rsvmcs.qcrsip.test;

import com.rsvmcs.qcrsip.entity.SipListener;

public interface ISIPProcessorObserver extends SipListener {
}
