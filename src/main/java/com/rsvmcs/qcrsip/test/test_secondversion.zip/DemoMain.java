package com.rsvmcs.qcrsip.test;


import com.rsvmcs.qcrsip.core.SipProviderImpl;
import com.rsvmcs.qcrsip.core.SipStackImpl;
import com.rsvmcs.qcrsip.entity.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.util.UUID;

/**
 * Demo:
 *  - create UDP and TCP listeningPoint & provider
 *  - register a business SipListener that auto-replies 200 OK
 *  - send one INVITE via UDP and one via TCP through providers (using connection pool for TCP)
 */
@SpringBootApplication
@EnableScheduling
@ComponentScan({"com.rsvmcs.qcrsip"})
public class DemoMain implements CommandLineRunner {

    private final static Logger logger = LoggerFactory.getLogger(DemoMain.class);


//    public static void main(String[] args) {
//        SpringApplication.run(DemoMain.class, args);
//        System.out.println("qcr自定义sip库启动成功！ﾞ  \n");
//    }

    @Override
    public void run(String... args) throws Exception {

    }

    // send UDP INVITE
//        RequestLine rl = new RequestLine("INVITE", "sip:service@127.0.0.1", "SIP/2.0");
//        SipRequest req = new SipRequest(rl);
//        req.setHeader("Via", "SIP/2.0/UDP 127.0.0.1:5060");
//        req.setHeader("To", "<sip:service@127.0.0.1>");
//        req.setHeader("From", "<sip:client@127.0.0.1>;tag=abc");
//        req.setHeader("Call-ID", UUID.randomUUID().toString());
//        req.setHeader("CSeq", "1 INVITE"); // transaction key = "1"
//        req.setRawContent("<?xml version='1.0' encoding='GB2312'?><request command='test'></request>".getBytes(SIPMessage.GB2312));
//        req.setDestination("10.120.5.185", 5061, Request.Transport.UDP);
//        System.out.println("Sending UDP INVITE...");
//        udpImpl.sendRequest(req);

//        // send TCP INVITE (will use ConnectionManager async)
//        RequestLine rl2 = new RequestLine("INVITE", "sip:service@127.0.0.1", "SIP/2.0");
//        SipRequest req2 = new SipRequest(rl2);
//        req2.setHeader("Via", "SIP/2.0/TCP 127.0.0.1:5060");
//        req2.setHeader("To", "<sip:service@127.0.0.1>");
//        req2.setHeader("From", "<sip:client@127.0.0.1>;tag=def");
//        req2.setHeader("Call-ID", UUID.randomUUID().toString());
//        req2.setHeader("CSeq", "2 INVITE");
//        req2.setRawContent("<?xml version='1.0' encoding='GB2312'?><request command='test2'></request>".getBytes(SIPMessage.GB2312));
//        req2.setDestination("10.120.5.185", 5061, Request.Transport.TCP);
//        System.out.println("Sending TCP INVITE...");
//        tcpImpl.sendRequest(req2);
//
//        // let demo run a bit
//        Thread.sleep(8000);
//        System.out.println("Demo finished.");
        //System.exit(0);


}