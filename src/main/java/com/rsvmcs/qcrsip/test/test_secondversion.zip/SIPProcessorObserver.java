package com.rsvmcs.qcrsip.test;

import com.rsvmcs.qcrsip.entity.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class SIPProcessorObserver implements ISIPProcessorObserver {

    private final static Logger logger = LoggerFactory.getLogger(SIPProcessorObserver.class);

    @Override
    public void processRequest(RequestEvent requestEvent) {
        logger.debug("\n收到请求：\n{}", requestEvent.getRequest());
        RequestLine requestLine = requestEvent.getRequest().getRequestLine();
        if (requestLine != null) {
            logger.debug("\nmethod：{},uri:{},version{}", requestLine.getMethod(), requestLine.getUri(), requestLine.getVersion());

            logger.debug("content:{}", new String(requestEvent.getRequest().getRawContent()));

            System.out.println("BUSINESS GOT REQUEST from " + requestEvent.getRemoteAddress() + ":" + requestEvent.getRemotePort() + " transport=" + requestEvent.getTransport());
            System.out.println(new String(requestEvent.getRequest().getRawContent() == null ? new byte[0] : requestEvent.getRequest().getRawContent(), SIPMessage.GB2312));
            // build 200 OK
            SipResponse resp = new SipResponse(new StatusLine("SIP/2.0", 200, "OK"));
            resp.setHeader("Via", requestEvent.getRequest().getHeader("Via"));
            resp.setHeader("Call-ID", requestEvent.getRequest().getHeader("Call-ID"));
            resp.setHeader("CSeq", requestEvent.getRequest().getHeader("CSeq"));
            resp.setHeader("From", requestEvent.getRequest().getHeader("From"));
            resp.setHeader("To", requestEvent.getRequest().getHeader("To"));
            String body = "<?xml version='1.0' encoding='GB2312'?><response command='ok'><result code='0'>OK</result></response>";
            resp.setRawContent(body.getBytes(SIPMessage.GB2312));
            try {
                // provider will route response using CSeq mapping or fallback to destination fields
                if (requestEvent.getTransport() == ListeningPoint.Transport.TCP) {
                    // set destination to remote (not strictly necessary because mapping should exist)
                    resp.setDestination(requestEvent.getRemoteAddress().getHostAddress(), requestEvent.getRemotePort(), Request.Transport.TCP);
                    // tcpImpl.sendResponse(resp);
                } else {
                    resp.setDestination(requestEvent.getRemoteAddress().getHostAddress(), requestEvent.getRemotePort(), Request.Transport.UDP);
                    // udpImpl.sendResponse(resp);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public void processResponse(ResponseEvent responseEvent) {
        System.out.println("BUSINESS GOT RESPONSE from " + responseEvent.getRemoteAddress() + ":" + responseEvent.getRemotePort());
        System.out.println(new String(responseEvent.getResponse().getRawContent() == null ? new byte[0] : responseEvent.getResponse().getRawContent(), SIPMessage.GB2312));
    }

    @Override
    public void processTimeout(TimeoutEvent timeoutEvent) {
        System.out.println("TIMEOUT: " + timeoutEvent.getTransactionKey());
    }
}
