package secondVersion.sipsim.test;

import secondVersion.sipsim.bak.SipLikeMessage;
import secondVersion.sipsim.bak.SipRequestEvent;
import secondVersion.sipsim.bak.SipResponseEvent;

import java.util.EventObject;

public class SIPProcessorObserver implements ISIPProcessorObserver {

    @Override
    public void processRequest(EventObject evt) {
        if (evt instanceof SipRequestEvent) {
            System.out.println("[Observer] processRequest: " + ((SipRequestEvent) evt).getMessage());
        }
    }

    @Override
    public void processResponse(EventObject evt) {
        if (evt instanceof SipResponseEvent) {
            System.out.println("[Observer] processResponse: " + ((SipResponseEvent) evt).getMessage());
        }
    }

    @Override
    public void onTimeout(EventObject evt) {
        System.out.println("[Observer] timeout: " + evt);
    }

    @Override
    public void onError(Object error) {
        System.err.println("[Observer] error: " + error);
    }

    @Override
    public void onDisconnect(EventObject evt) {
        System.out.println("[Observer] disconnect: " + evt);
    }

    // For compatibility with SipListener
    public void onRequestReceived(SipLikeMessage msg) {
        System.out.println("[Observer] onRequestReceived: " + msg);
    }
}
