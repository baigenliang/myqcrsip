package secondVersion.sipsim.common;

import secondVersion.sipsim.bak.ListeningPoint;

public interface SipStack {
    ListeningPoint createListeningPoint(String ipAddress, int port, String transport) throws Exception;
    SipProvider createSipProvider(ListeningPoint listeningPoint) throws Exception;
}
