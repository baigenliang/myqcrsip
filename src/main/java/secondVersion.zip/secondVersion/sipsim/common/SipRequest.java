package secondVersion.sipsim.common;

import secondVersion.sipsim.common.RequestLine;
import secondVersion.sipsim.common.Response;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

public class SipRequest extends SIPMessage implements Request {
    private RequestLine requestLine;

    public SipRequest(String method, String uri, String version) {
        this.requestLine = new RequestLine(method, uri, version);
    }

    public RequestLine getRequestLine() {
        return requestLine;
    }

    public String getMethod() {
        return requestLine.getMethod();
    }

    @Override
    protected void appendStartLine(StringBuilder sb) {
        sb.append(requestLine.toString()).append("\r\n");
    }
//    // build convenience (后续测试可用）
//    public static SipRequest createInvite(String targetUri, String viaHost, String from, String to, String callId, int cseq, String xmlBody) {
//        SipRequest r = new SipRequest();
//        r.startLine = "INVITE " + targetUri + " SIP/2.0";
//        r.headers.put("Via", "SIP/2.0/TCP " + viaHost);
//        r.headers.put("To", to);
//        r.headers.put("From", from);
//        r.headers.put("Max-Forwards", "70");
//        r.headers.put("Call-ID", callId);
//        r.headers.put("CSeq", cseq + " INVITE");
//        r.headers.put("Content-Type", "RVSS/xml");
//        r.body = xmlBody == null ? new byte[0] : xmlBody.getBytes(GB2312);
//        return r;
//    }
}
