package secondVersion.sipsim.common;

public interface Request {
    String getMethod();
    RequestLine getRequestLine();
    String getHeader(String name);
    void setHeader(String name, String value);
    void setContent(String content);
    String getContent();

}
