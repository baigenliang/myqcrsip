package secondVersion.sipsim.common;

import java.io.IOException;

public interface SipProvider {

//    /**
//     * 添加监听点（IP + 端口）
//     */
//    void addListeningPoint(String ip, int port) throws IOException;
//
//    /**
//     * 移除监听点
//     */
//    void removeListeningPoint(String ip, int port);
//
//    /**
//     * 获取指定监听点
//     */
//    ListeningPoint getListeningPoint(String ip, int port);
//
//    /**
//     * 获取所有监听点列表
//     */
//    List<ListeningPoint> getListeningPoints();
//
//
//    /**
//     * 调度接收的消息（请求或响应）
//     */
//    void dispatchIncoming(SIPMessage message);
//
//    /**
//     * 监听点封装类
//     */
//    public static class ListeningPoint {
//        private final String ip;
//        private final int port;
//
//        public ListeningPoint(String ip, int port) {
//            this.ip = ip;
//            this.port = port;
//        }
//
//        public String getIp() { return ip; }
//        public int getPort() { return port; }
//    }

    void sendRequest(Request request) throws IOException;

    void sendResponse(Response response) throws IOException;


    void addSipListener(SipListener sipListener);
    void removeSipListener(SipListener sipListener);
    SipListener getSipListener();



}
