package secondVersion.sipsim.common;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
//
//public abstract class SIPMessage {
//    protected Map<String, String> headers = new LinkedHashMap<>();
//    protected byte[] rawContent;
//
//    public Map<String, String> getHeaders() {
//        return headers;
//    }
//
//    public String getHeader(String name) {
//        return headers.get(name);
//    }
//
//    public void setHeader(String name, String value) {
//        headers.put(name, value);
//    }
//
//    public byte[] getRawContent() {
//        return rawContent;
//    }
//
//    public String getBodyAsString() {
//        return rawContent != null ? new String(rawContent) : "";
//    }
//
//    public void setRawContent(byte[] content) {
//        this.rawContent = content;
//    }
//
//    public abstract String encode();
//
//    /**
//     * 解析字符串为 SIPMessage（自动识别是请求还是响应）
//     */
//    public static SIPMessage parse(String data) {
//        String[] parts = data.split("\r\n\r\n", 2);
//        String headerPart = parts[0];
//        String bodyPart = parts.length > 1 ? parts[1] : "";
//
//        String[] headerLines = headerPart.split("\r\n");
//        String startLine = headerLines[0];
//
//        if (startLine.startsWith("SIP/2.0")) {
//            // 响应
//            StatusLine statusLine = StatusLine.parse(startLine);
//            SipResponse response = new SipResponse(statusLine);
//            for (int i = 1; i < headerLines.length; i++) {
//                String line = headerLines[i];
//                int idx = line.indexOf(':');
//                if (idx > 0) {
//                    String name = line.substring(0, idx).trim();
//                    String value = line.substring(idx + 1).trim();
//                    response.setHeader(name, value);
//                }
//            }
//            response.setRawContent(bodyPart.getBytes());
//            return response;
//        } else {
//            // 请求
//            RequestLine requestLine = RequestLine.parse(startLine);
//            SipRequest request = new SipRequest(requestLine);
//            for (int i = 1; i < headerLines.length; i++) {
//                String line = headerLines[i];
//                int idx = line.indexOf(':');
//                if (idx > 0) {
//                    String name = line.substring(0, idx).trim();
//                    String value = line.substring(idx + 1).trim();
//                    request.setHeader(name, value);
//                }
//            }
//            request.setRawContent(bodyPart.getBytes());
//            return request;
//        }
//    }
//}

public abstract class SIPMessage {
    protected Map<String, String> headers = new LinkedHashMap<>();
    protected String content;

    public String getHeader(String name) {
        return headers.get(name);
    }

    public void setHeader(String name, String value) {
        headers.put(name, value);
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    /** 将 SIP 消息序列化为字符串 */
    public String toString() {
        StringBuilder sb = new StringBuilder();
        appendStartLine(sb);
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            sb.append(entry.getKey()).append(": ").append(entry.getValue()).append("\r\n");
        }
        sb.append("\r\n");
        if (content != null) {
            sb.append(content);
        }
        return sb.toString();
    }

    protected abstract void appendStartLine(StringBuilder sb);
}