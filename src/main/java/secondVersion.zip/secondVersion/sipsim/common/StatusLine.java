package secondVersion.sipsim.common;



// 响应行
public class StatusLine {
    private String version;
    private int statusCode;
    private String reasonPhrase;

    public StatusLine(String version, int statusCode, String reasonPhrase) {
        this.version = version;
        this.statusCode = statusCode;
        this.reasonPhrase = reasonPhrase;
    }

    public String getVersion() {
        return version;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public String getReasonPhrase() {
        return reasonPhrase;
    }

    public String toString() {
        return version + " " + statusCode + " " + reasonPhrase;
    }
}