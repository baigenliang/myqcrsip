package secondVersion.sipsim.common;

import java.net.InetAddress;
import java.net.Socket;
import java.util.EventObject;

public class RequestEvent {
    private final Request request;
    private final InetAddress remoteAddress;
    private final int remotePort;
    private final Socket socket;

    // 构造方法1：UDP 场景
    public RequestEvent(Request request, InetAddress remoteAddress, int remotePort) {
        this.request = request;
        this.remoteAddress = remoteAddress;
        this.remotePort = remotePort;
        this.socket = null;
    }

    // 构造方法2：TCP 场景
    public RequestEvent(Request request, Socket socket) {
        this.request = request;
        this.socket = socket;
        this.remoteAddress = socket.getInetAddress();
        this.remotePort = socket.getPort();
    }

    public Request getRequest() {
        return request;
    }

    public InetAddress getRemoteAddress() {
        return remoteAddress;
    }

    public int getRemotePort() {
        return remotePort;
    }

    public Socket getSocket() {
        return socket;
    }
}