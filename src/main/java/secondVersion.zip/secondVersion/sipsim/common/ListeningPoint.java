package secondVersion.sipsim.common;

public class ListeningPoint {
    private String ipAddress;
    private int port;
    private String transport;

    public ListeningPoint(String ipAddress, int port, String transport) {
        this.ipAddress = ipAddress;
        this.port = port;
        this.transport = transport.toUpperCase();
    }

    public String getIpAddress() { return ipAddress; }
    public int getPort() { return port; }
    public String getTransport() { return transport; }
}
