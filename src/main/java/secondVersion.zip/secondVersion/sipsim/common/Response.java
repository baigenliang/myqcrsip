package secondVersion.sipsim.common;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

public interface Response {
    int getStatusCode();
    String getReasonPhrase();
    StatusLine getStatusLine();
    String getHeader(String name);
    void setHeader(String name, String value);
    void setContent(String content);
    String getContent();
}
