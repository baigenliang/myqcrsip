package secondVersion.sipsim.common;

import java.net.InetAddress;
import java.net.Socket;
import java.util.EventObject;


public class ResponseEvent {
    private final Response response;
    private final InetAddress remoteAddress;
    private final int remotePort;
    private final Socket socket;

    // 构造方法1：UDP 场景
    public ResponseEvent(Response response, InetAddress remoteAddress, int remotePort) {
        this.response = response;
        this.remoteAddress = remoteAddress;
        this.remotePort = remotePort;
        this.socket = null;
    }

    // 构造方法2：TCP 场景
    public ResponseEvent(Response response, Socket socket) {
        this.response = response;
        this.socket = socket;
        this.remoteAddress = socket.getInetAddress();
        this.remotePort = socket.getPort();
    }

    public Response getResponse() {
        return response;
    }

    public InetAddress getRemoteAddress() {
        return remoteAddress;
    }

    public int getRemotePort() {
        return remotePort;
    }

    public Socket getSocket() {
        return socket;
    }
}
