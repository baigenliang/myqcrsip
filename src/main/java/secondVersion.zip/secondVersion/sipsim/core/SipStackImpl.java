package secondVersion.sipsim.core;

import secondVersion.sipsim.common.ListeningPoint;
import secondVersion.sipsim.common.SipProvider;
import secondVersion.sipsim.common.SipStack;

public class SipStackImpl implements SipStack {
    @Override
    public ListeningPoint createListeningPoint(String ipAddress, int port, String transport) throws Exception {
        return new ListeningPoint(ipAddress, port, transport);
    }

    @Override
    public SipProvider createSipProvider(ListeningPoint listeningPoint) throws Exception {
        return new SipProviderImpl(listeningPoint);
    }
}