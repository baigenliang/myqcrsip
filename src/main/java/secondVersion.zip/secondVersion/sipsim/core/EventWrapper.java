package secondVersion.sipsim.core;


import java.util.EventObject;

public class EventWrapper {
    public enum EventType { REQUEST, RESPONSE, TIMEOUT, ERROR, DISCONNECT }

    private final EventType eventType;
    private final EventObject event;
    private final long timestamp;

    public EventWrapper(EventType eventType, EventObject event) {
        this.eventType = eventType;
        this.event = event;
        this.timestamp = System.currentTimeMillis();
    }

    public EventType getEventType() { return eventType; }
    public EventObject getEvent() { return event; }
    public long getTimestamp() { return timestamp; }
}