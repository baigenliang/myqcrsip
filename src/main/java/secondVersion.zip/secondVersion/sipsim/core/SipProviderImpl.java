////package secondVersion.sipsim.core;
////
////import secondVersion.sipsim.common.*;
////
////import java.io.IOException;
////import java.nio.charset.StandardCharsets;
////import java.util.*;
////import java.util.concurrent.ConcurrentHashMap;
////
////
/////**
//// * SipProviderImpl 负责：
//// * - 管理监听点（add/remove/get/getAll）
//// * - 管理 SipListeners
//// * - 提供 sendRequest/sendResponse（转给 TransportManager）
//// * - dispatchIncoming(Event) 将 RequestEvent/ResponseEvent 转给 listeners
//// */
////public class SipProviderImpl extends  SipProvider{
//////    private final TransportManager transport;
//////    private final BlockingQueue<EventObject> eventQueue;
//////    private final Map<String, ListeningPoint> lpMap = new LinkedHashMap<>();
//////    private final List<SipListener> listeners = Collections.synchronizedList(new ArrayList<>());
//////
//////    public SipProviderImpl(TransportManager transport, BlockingQueue<EventObject> eventQueue) {
//////        this.transport = transport;
//////        this.eventQueue = eventQueue;
//////    }
//////
//////    // ListeningPoint management
//////    public void addListeningPoint(ListeningPoint lp) throws IOException {
//////        String key = lp.key();
//////        if (lpMap.containsKey(key)) return;
//////        lpMap.put(key, lp);
//////        transport.addListeningPoint(lp);
//////    }
//////
//////    public void removeListeningPoint(ListeningPoint lp) {
//////        String key = lp.key();
//////        if (!lpMap.containsKey(key)) return;
//////        lpMap.remove(key);
//////        transport.removeListeningPoint(lp);
//////    }
//////
//////    // get listening point by transport (returns first match), or null
//////    public ListeningPoint getListeningPoint(ListeningPoint.Transport transportType) {
//////        for (ListeningPoint lp : lpMap.values()) {
//////            if (lp.getTransport() == transportType) return lp;
//////        }
//////        return null;
//////    }
//////
//////    // get by ip/port/transport
//////    public ListeningPoint getListeningPoint(String ip, int port, ListeningPoint.Transport transportType) {
//////        return lpMap.get(ip + ":" + port + ":" + transportType.name());
//////    }
//////
//////    public ListeningPoint[] getListeningPoints() {
//////        return lpMap.values().toArray(new ListeningPoint[0]);
//////    }
//////
//////    // SipListener management
//////    public void addSipListener(SipListener l) { listeners.add(l); }
//////    public void removeSipListener(SipListener l) { listeners.remove(l); }
////
////    // dispatch incoming event (called by EventScanner)
//////    public void dispatchIncoming(EventObject ev) {
//////        if (ev instanceof RequestEvent) {
//////            RequestEvent re = (RequestEvent) ev;
//////            // notify listeners about incoming request
//////            for (SipListener l : listeners) {
//////                try { l.processRequest(re); } catch (Throwable t) { t.printStackTrace(); }
//////            }
//////            // optionally: automatically send 200 OK (you can remove or make configurable)
//////            try {
//////                SipResponse resp = SipResponse.create200OkFrom(re.getRequest());
//////                // find via header to determine destination; fallback to localhost: use default
//////                String via = re.getRequest().getHeader("Via");
//////                InetSocketAddress dst = new InetSocketAddress("127.0.0.1", 5060);
//////                if (via != null) {
//////                    String after = via.substring(via.lastIndexOf(' ') + 1).trim();
//////                    String[] hp = after.split(":");
//////                    if (hp.length == 2) dst = new InetSocketAddress(hp[0], Integer.parseInt(hp[1]));
//////                }
//////                // send via UDP by default
//////                transport.sendUdp(dst.getHostString(), dst.getPort(), resp.toBytes());
//////            } catch (Exception e) {
//////                e.printStackTrace();
//////            }
//////        } else if (ev instanceof ResponseEvent) {
//////            ResponseEvent re = (ResponseEvent) ev;
//////            for (SipListener l : listeners) {
//////                try { l.processResponse(re); } catch (Throwable t) { t.printStackTrace(); }
//////            }
//////        } else {
//////            // ignore or extend for timeout/error events
//////        }
//////    }
//////
//////    // business API to send request/response
//////    public void sendRequest(SipRequest req, ListeningPoint.Transport transportProto, String dstHost, int dstPort) throws IOException {
//////        byte[] data = req.toBytes();
//////        if (transportProto == ListeningPoint.Transport.UDP) transport.sendUdp(dstHost, dstPort, data);
//////        else transport.sendTcp(dstHost, dstPort, data);
//////    }
//////
//////    public void sendResponse(SipResponse resp, ListeningPoint.Transport transportProto, String dstHost, int dstPort) throws IOException {
//////        byte[] data = resp.toBytes();
//////        if (transportProto == ListeningPoint.Transport.UDP) transport.sendUdp(dstHost, dstPort, data);
//////        else transport.sendTcp(dstHost, dstPort, data);
//////    }
////
////    private List<SipListener> listeners = new ArrayList<>();
////    private Map<String, ListeningPoint> listeningPoints = new ConcurrentHashMap<>();
////    private TransportManager transportManager;
////
////    public SipProviderImpl() {
////        this.transportManager = new TransportManager(this);
////    }
////
////    public void addListeningPoint(ListeningPoint lp) {
////        listeningPoints.put(lp.getIp() + ":" + lp.getPort(), lp);
////    }
////
////    public ListeningPoint getListeningPoint(String ip, int port) {
////        return listeningPoints.get(ip + ":" + port);
////    }
////
////    public Collection<ListeningPoint> getListeningPoints() {
////        return listeningPoints.values();
////    }
////
////    public void addSipListener(SipListener listener) {
////        listeners.add(listener);
////    }
////
////    public void dispatchIncoming(Object event) {
////        for (SipListener listener : listeners) {
////            if (event instanceof RequestEvent) {
////                listener.processRequest((RequestEvent) event);
////            } else if (event instanceof ResponseEvent) {
////                listener.processResponse((ResponseEvent) event);
////            }
////        }
////    }
////
////    public void sendRequest(SipRequest request, String host, int port) throws IOException {
////        byte[] data = request.encode().getBytes(StandardCharsets.UTF_8);
////        transportManager.sendBytes(host, port, data);
////    }
////
////    public void sendResponse(SipResponse response, String host, int port) throws IOException {
////        byte[] data = response.encode().getBytes(StandardCharsets.UTF_8);
////        transportManager.sendBytes(host, port, data);
////    }
////}
//
//package secondVersion.sipsim.core;
//
//import secondVersion.sipsim.common.*;
//
//import java.io.OutputStream;
//import java.net.*;
//import java.util.concurrent.*;
//
//
//public class SipProviderImpl implements SipProvider {
//    private ListeningPoint listeningPoint;
//    private SipListener sipListener;
//    private ExecutorService executor = Executors.newCachedThreadPool();
//
//    public SipProviderImpl(ListeningPoint listeningPoint) throws Exception {
//        this.listeningPoint = listeningPoint;
//        if ("UDP".equals(listeningPoint.getTransport())) {
//            startUdpReceiver();
//        } else if ("TCP".equals(listeningPoint.getTransport())) {
//            startTcpReceiver();
//        }
//    }
//
//    @Override
//    public void addSipListener(SipListener sipListener) {
//        this.sipListener = sipListener;
//    }
//
//    @Override
//    public void removeSipListener(SipListener sipListener) {
//        if (this.sipListener == sipListener) {
//            this.sipListener = null;
//        }
//    }
//
//    @Override
//    public SipListener getSipListener() {
//        return this.sipListener;
//    }
//
//    @Override
//    public void sendRequest(Request request) throws Exception {
//        byte[] data = request.encode().getBytes();
//        if ("UDP".equals(listeningPoint.getTransport())) {
//            DatagramSocket socket = new DatagramSocket();
//            InetAddress targetAddr = InetAddress.getByName(request.getDestinationHost());
//            DatagramPacket packet = new DatagramPacket(data, data.length, targetAddr, request.getDestinationPort());
//            socket.send(packet);
//            socket.close();
//        } else {
//            Socket socket = new Socket(request.getDestinationHost(), request.getDestinationPort());
//            OutputStream out = socket.getOutputStream();
//            out.write(data);
//            out.flush();
//            socket.close();
//        }
//    }
//
//    @Override
//    public void sendResponse(Response response) throws Exception {
//        byte[] data = response.encode().getBytes();
//        if ("UDP".equals(listeningPoint.getTransport())) {
//            DatagramSocket socket = new DatagramSocket();
//            InetAddress targetAddr = InetAddress.getByName(response.getDestinationHost());
//            DatagramPacket packet = new DatagramPacket(data, data.length, targetAddr, response.getDestinationPort());
//            socket.send(packet);
//            socket.close();
//        } else {
//            Socket socket = response.getAssociatedSocket();
//            if (socket != null && socket.isConnected()) {
//                OutputStream out = socket.getOutputStream();
//                out.write(data);
//                out.flush();
//            } else {
//                throw new Exception("No TCP connection to send response");
//            }
//        }
//    }
//
//    private void startUdpReceiver() throws Exception {
//        DatagramSocket socket = new DatagramSocket(listeningPoint.getPort(), InetAddress.getByName(listeningPoint.getIpAddress()));
//        executor.submit(() -> {
//            byte[] buf = new byte[8192];
//            while (true) {
//                DatagramPacket packet = new DatagramPacket(buf, buf.length);
//                socket.receive(packet);
//                String msg = new String(packet.getData(), 0, packet.getLength());
//                if (msg.startsWith("SIP/2.0")) {
//                    if (sipListener != null) sipListener.processResponse(new ResponseEvent(msg, packet.getAddress(), packet.getPort()));
//                } else {
//                    if (sipListener != null) sipListener.processRequest(new RequestEvent(msg, packet.getAddress(), packet.getPort()));
//                }
//            }
//        });
//    }
//
//    private void startTcpReceiver() throws Exception {
//        ServerSocket serverSocket = new ServerSocket(listeningPoint.getPort(), 50, InetAddress.getByName(listeningPoint.getIpAddress()));
//        executor.submit(() -> {
//            while (true) {
//                Socket socket = serverSocket.accept();
//                executor.submit(() -> {
//                    try {
//                        byte[] buf = new byte[8192];
//                        int len = socket.getInputStream().read(buf);
//                        if (len > 0) {
//                            String msg = new String(buf, 0, len);
//                            if (msg.startsWith("SIP/2.0")) {
//                                if (sipListener != null) sipListener.processResponse(new ResponseEvent(msg, socket));
//                            } else {
//                                if (sipListener != null) sipListener.processRequest(new RequestEvent(msg, socket));
//                            }
//                        }
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }
//                });
//            }
//        });
//    }
//}