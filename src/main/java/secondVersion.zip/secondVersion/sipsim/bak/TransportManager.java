////package secondVersion.sipsim.core;
////
////
////import secondVersion.sipsim.common.*;
////
////import java.io.*;
////import java.net.*;
////import java.nio.charset.StandardCharsets;
////import java.util.Map;
////import java.util.concurrent.*;
////
/////**
//// * TransportManager 支持多个 ListeningPoint：
//// * - 对于每个 ListeningPoint (UDP/TCP)，启动相应 listener 线程
//// * - 收到原始 bytes -> SIPMessage.parse -> put Event (RequestEvent/ResponseEvent) 到 eventQueue
//// *
//// * 提供 sendUdp / sendTcp 方法用于发送。
//// */
////public class TransportManager {
//////    private final BlockingQueue<EventObject> eventQueue;
//////    private final ExecutorService executor = Executors.newCachedThreadPool();
//////    private final ConcurrentMap<String, ListeningPoint> listeningPoints = new ConcurrentHashMap<>();
//////    private final ConcurrentMap<String, DatagramSocket> udpSockets = new ConcurrentHashMap<>();
//////    private final ConcurrentMap<String, ServerSocket> tcpServerSockets = new ConcurrentHashMap<>();
//////    private final ConcurrentMap<Socket, Future<?>> tcpConnFutures = new ConcurrentHashMap<>();
//////    private volatile boolean running = true;
//////
//////    public TransportManager(BlockingQueue<EventObject> eventQueue) {
//////        this.eventQueue = eventQueue;
//////    }
//////
//////    // Add a listening point and start its listeners
//////    public synchronized void addListeningPoint(ListeningPoint lp) throws IOException {
//////        String key = lp.key();
//////        if (listeningPoints.putIfAbsent(key, lp) != null) {
//////            // already present
//////            return;
//////        }
//////
//////        if (lp.getTransport() == ListeningPoint.Transport.UDP) {
//////            DatagramSocket ds = new DatagramSocket(null);
//////            ds.setReuseAddress(true);
//////            ds.bind(new InetSocketAddress(lp.getIp(), lp.getPort()));
//////            udpSockets.put(key, ds);
//////            executor.submit(() -> udpListenLoop(lp, ds));
//////            System.out.println("TransportManager: started UDP listener on " + lp);
//////        } else {
//////            ServerSocket ss = new ServerSocket();
//////            ss.setReuseAddress(true);
//////            ss.bind(new InetSocketAddress(lp.getIp(), lp.getPort()));
//////            tcpServerSockets.put(key, ss);
//////            executor.submit(() -> tcpAcceptLoop(lp, ss));
//////            System.out.println("TransportManager: started TCP listener on " + lp);
//////        }
//////    }
//////
//////    // Remove a listening point and stop listener
//////    public synchronized void removeListeningPoint(ListeningPoint lp) {
//////        String key = lp.key();
//////        listeningPoints.remove(key);
//////        if (udpSockets.containsKey(key)) {
//////            DatagramSocket ds = udpSockets.remove(key);
//////            if (ds != null) ds.close();
//////            System.out.println("TransportManager: stopped UDP listener on " + lp);
//////        }
//////        if (tcpServerSockets.containsKey(key)) {
//////            ServerSocket ss = tcpServerSockets.remove(key);
//////            if (ss != null) {
//////                try { ss.close(); } catch (IOException ignored) {}
//////            }
//////            System.out.println("TransportManager: stopped TCP listener on " + lp);
//////        }
//////    }
//////
//////    public ListeningPoint[] getListeningPoints() {
//////        return listeningPoints.values().toArray(new ListeningPoint[0]);
//////    }
//////
//////    // UDP listen loop
//////    private void udpListenLoop(ListeningPoint lp, DatagramSocket ds) {
//////        byte[] buf = new byte[8192];
//////        DatagramPacket pkt = new DatagramPacket(buf, buf.length);
//////        while (running && !ds.isClosed()) {
//////            try {
//////                ds.receive(pkt);
//////                byte[] data = new byte[pkt.getLength()];
//////                System.arraycopy(pkt.getData(), pkt.getOffset(), data, 0, pkt.getLength());
//////                handleReceivedBytes(data, new InetSocketAddress(pkt.getAddress(), pkt.getPort()));
//////            } catch (SocketException se) {
//////                // socket closed
//////                break;
//////            } catch (IOException ioe) {
//////                ioe.printStackTrace();
//////            }
//////        }
//////    }
//////
//////    // TCP accept loop - accept new connections and spawn handler
//////    private void tcpAcceptLoop(ListeningPoint lp, ServerSocket ss) {
//////        while (running && !ss.isClosed()) {
//////            try {
//////                Socket s = ss.accept();
//////                Future<?> f = executor.submit(() -> handleTcpConnection(s));
//////                // store so we can cancel/close if needed
//////                tcpConnFutures.put(s, f);
//////            } catch (SocketException se) {
//////                break;
//////            } catch (IOException ioe) {
//////                ioe.printStackTrace();
//////            }
//////        }
//////    }
//////
//////    // handle a single tcp connection (reads possibly multiple messages, handles framing)
//////    private void handleTcpConnection(Socket s) {
//////        try (InputStream in = s.getInputStream()) {
//////            ByteArrayOutputStream acc = new ByteArrayOutputStream();
//////            byte[] buf = new byte[4096];
//////            int read;
//////            while ((read = in.read(buf)) != -1) {
//////                acc.write(buf, 0, read);
//////                byte[] accBytes = acc.toByteArray();
//////                // try to extract as many complete messages as available
//////                int processedBytes = 0;
//////                while (true) {
//////                    int msgLen = detectCompleteSipMessageLength(accBytes, processedBytes);
//////                    if (msgLen <= 0) break;
//////                    byte[] msgBytes = new byte[msgLen];
//////                    System.arraycopy(accBytes, processedBytes, msgBytes, 0, msgLen);
//////                    processedBytes += msgLen;
//////                    // handle message
//////                    try {
//////                        handleReceivedBytes(msgBytes, new InetSocketAddress(s.getInetAddress(), s.getPort()));
//////                    } catch (Exception ex) {
//////                        ex.printStackTrace();
//////                    }
//////                    if (processedBytes >= accBytes.length) break;
//////                    // loop to see if more complete messages are available
//////                }
//////                // keep any leftover bytes
//////                if (processedBytes > 0) {
//////                    byte[] left = new byte[accBytes.length - processedBytes];
//////                    if (left.length > 0) System.arraycopy(accBytes, processedBytes, left, 0, left.length);
//////                    acc.reset();
//////                    acc.write(left);
//////                }
//////            }
//////        } catch (IOException ioe) {
//////            // connection closed
//////        } finally {
//////            try { s.close(); } catch (IOException ignored) {}
//////        }
//////    }
//////
//////    // detect one complete SIP message starting at offset; return total length (header+4+body) or -1 if incomplete
//////    private int detectCompleteSipMessageLength(byte[] buf, int offset) {
//////        if (buf.length - offset < 4) return -1;
//////        // find \r\n\r\n
//////        int sep = -1;
//////        for (int i = offset; i < buf.length - 3; i++) {
//////            if (buf[i] == 13 && buf[i+1] == 10 && buf[i+2] == 13 && buf[i+3] == 10) { sep = i; break; }
//////        }
//////        if (sep == -1) return -1;
//////        String headerPart = new String(buf, offset, sep - offset, StandardCharsets.US_ASCII);
//////        int contentLength = 0;
//////        for (String line : headerPart.split("\\r\\n")) {
//////            if (line.toLowerCase().startsWith("content-length:")) {
//////                try { contentLength = Integer.parseInt(line.substring(line.indexOf(':') + 1).trim()); } catch (Exception ignored) {}
//////                break;
//////            }
//////        }
//////        int total = (sep - offset) + 4 + contentLength;
//////        if (buf.length - offset >= total) return total;
//////        return -1;
//////    }
////
////
////
////    private final Map<String, Socket> connectionMap = new ConcurrentHashMap<>();
////    private SipProviderImpl sipProvider;
////
////    public TransportManager(SipProviderImpl provider) {
////        this.sipProvider = provider;
////    }
////
////    public void addConnection(String host, int port) throws IOException {
////        Socket socket = new Socket(host, port);
////        connectionMap.put(host + ":" + port, socket);
////    }
////
////    public void sendBytes(String host, int port, byte[] data) throws IOException {
////        Socket socket = connectionMap.get(host + ":" + port);
////        if (socket != null && socket.isConnected()) {
////            socket.getOutputStream().write(data);
////            socket.getOutputStream().flush();
////        }
////    }
////    // called for each complete message bytes
////    private void handleReceivedBytes(byte[] data, InetSocketAddress remote) {
////        try {
////            SIPMessage msg = SIPMessage.parse(data);
////            if (msg instanceof SipRequest) {
////                eventQueue.put(new RequestEvent(this, (SipRequest) msg));
////            } else {
////                eventQueue.put(new ResponseEvent(this, (SipResponse) msg));
////            }
////        } catch (Exception e) {
////            e.printStackTrace();
////        }
////    }
////
////
////    /** 接收字节并解析为 SIPMessage */
////    public void handleReceivedBytes(byte[] bytes) {
////        try {
////            String dataStr = new String(bytes, StandardCharsets.UTF_8);
////            Response.SipMessage message = SIPMessage.parse(dataStr);
////
////            if (message instanceof SipRequest) {
////                sipProvider.dispatchIncoming(new RequestEvent(this, (SipRequest) message));
////            } else if (message instanceof SipResponse) {
////                sipProvider.dispatchIncoming(new ResponseEvent(this, (SipResponse) message));
////            }
////        } catch (Exception e) {
////            e.printStackTrace();
////        }
////    }
////
////
////    // send methods (stateless). You may extend to use long-lived TCP sockets if you want pooling.
////    public void sendUdp(String dstHost, int dstPort, byte[] data) throws IOException {
////        try (DatagramSocket ds = new DatagramSocket()) {
////            DatagramPacket pkt = new DatagramPacket(data, data.length, InetAddress.getByName(dstHost), dstPort);
////            ds.send(pkt);
////        }
////    }
////
////    public void sendTcp(String dstHost, int dstPort, byte[] data) throws IOException {
////        try (Socket s = new Socket(dstHost, dstPort);
////             OutputStream out = s.getOutputStream()) {
////            out.write(data);
////            out.flush();
////        }
////    }
////
////    public void stop() {
////        running = false;
////        // close UDP sockets
////        for (Map.Entry<String, DatagramSocket> e : udpSockets.entrySet()) {
////            try { e.getValue().close(); } catch (Exception ignored) {}
////        }
////        // close TCP server sockets
////        for (Map.Entry<String, ServerSocket> e : tcpServerSockets.entrySet()) {
////            try { e.getValue().close(); } catch (Exception ignored) {}
////        }
////        // shutdown executor
////        executor.shutdownNow();
////        System.out.println("TransportManager stopped.");
////    }
////}
//
//import secondVersion.sipsim.common.SIPMessage;
//import secondVersion.sipsim.common.SipRequest;
//import secondVersion.sipsim.common.SipResponse;
//import secondVersion.sipsim.core.EventWrapper;
//import secondVersion.sipsim.core.*;
//
//import java.io.*;
//import java.net.*;
//import java.util.*;
//import java.util.concurrent.*;
//
//public class TransportManager {
//
//    private final EventScanner eventScanner;
//
//    // key = ListeningPointKey(ip:port)
//    private final Map<String, ListeningPointSocket> listeningPoints = new ConcurrentHashMap<>();
//
//    public TransportManager(EventScanner eventScanner) {
//        this.eventScanner = eventScanner;
//    }
//
//    public void addListeningPoint(String ip, int port) throws IOException {
//        String key = key(ip, port);
//        if (listeningPoints.containsKey(key)) {
//            return; // 已经存在
//        }
//
//        ListeningPointSocket lp = new ListeningPointSocket(ip, port);
//        listeningPoints.put(key, lp);
//        lp.start();
//        System.out.printf("TransportManager: Listening on %s:%d%n", ip, port);
//    }
//
//    public void removeListeningPoint(String ip, int port) {
//        String key = key(ip, port);
//        ListeningPointSocket lp = listeningPoints.remove(key);
//        if (lp != null) {
//            lp.shutdown();
//            System.out.printf("TransportManager: Stopped listening on %s:%d%n", ip, port);
//        }
//    }
//
//    public List<String> getListeningPoints() {
//        return new ArrayList<>(listeningPoints.keySet());
//    }
//
//    /**
//     * 发送消息(直接写入对应的监听点的连接池中一个socket)
//     * 简单轮询分配，或可扩展更复杂连接管理
//     */
//    public void sendMessage(String ip, int port, byte[] data) throws IOException {
//        String key = key(ip, port);
//        ListeningPointSocket lp = listeningPoints.get(key);
//        if (lp == null) throw new IOException("ListeningPoint not found: " + ip + ":" + port);
//        lp.send(data);
//    }
//
//    private String key(String ip, int port) {
//        return ip + ":" + port;
//    }
//
//    /**
//     * 监听点封装TCP Server和连接池
//     */
//    private class ListeningPointSocket {
//        private final String ip;
//        private final int port;
//        private volatile boolean running = true;
//        private ServerSocket serverSocket;
//        private final ExecutorService executor = Executors.newCachedThreadPool();
//        private final List<ClientHandler> clients = Collections.synchronizedList(new ArrayList<>());
//        private int roundRobinIndex = 0;
//
//        ListeningPointSocket(String ip, int port) throws IOException {
//            this.ip = ip;
//            this.port = port;
//            this.serverSocket = new ServerSocket();
//            this.serverSocket.bind(new InetSocketAddress(ip, port));
//        }
//
//        void start() {
//            executor.submit(() -> {
//                while (running) {
//                    try {
//                        Socket client = serverSocket.accept();
//                        ClientHandler handler = new ClientHandler(client);
//                        clients.add(handler);
//                        executor.submit(handler);
//                        System.out.printf("Accepted client %s:%d on %s:%d%n",
//                                client.getInetAddress().getHostAddress(),
//                                client.getPort(), ip, port);
//                    } catch (IOException e) {
//                        if (!running) break;
//                        eventScanner.addEvent(new EventWrapper(EventWrapper.EventType.ERROR, new java.util.EventObject(e)));
//                    }
//                }
//            });
//        }
//
//        void shutdown() {
//            running = false;
//            try {
//                serverSocket.close();
//            } catch (IOException ignored) {}
//            synchronized (clients) {
//                for (ClientHandler h : clients) {
//                    h.shutdown();
//                }
//            }
//            executor.shutdown();
//        }
//
//        /**
//         * 发送数据（简单轮询一个连接发送）
//         */
//        void send(byte[] data) throws IOException {
//            ClientHandler handler = null;
//            synchronized (clients) {
//                if (clients.isEmpty()) {
//                    throw new IOException("No clients connected on " + ip + ":" + port);
//                }
//                handler = clients.get(roundRobinIndex % clients.size());
//                roundRobinIndex++;
//            }
//            handler.send(data);
//        }
//
//        /**
//         * 连接客户端处理线程
//         */
//        private class ClientHandler implements Runnable {
//            private final Socket socket;
//            private final InputStream in;
//            private final OutputStream out;
//            private volatile boolean connected = true;
//
//            ClientHandler(Socket socket) throws IOException {
//                this.socket = socket;
//                this.in = socket.getInputStream();
//                this.out = socket.getOutputStream();
//            }
//
//            @Override
//            public void run() {
//                try {
//                    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
//                    byte[] temp = new byte[4096];
//                    int read;
//
//                    while (connected && (read = in.read(temp)) != -1) {
//                        buffer.write(temp, 0, read);
//                        byte[] data = buffer.toByteArray();
//
//                        // 判断是否接收到完整消息（通过 \r\n\r\n 分割头部和body）
//                        int idx = indexOfDoubleCRLF(data);
//                        if (idx != -1) {
//                            // 已接收完整消息
//                            byte[] messageBytes = Arrays.copyOf(data, data.length);
//                            buffer.reset();
//
//                            try {
//                                SIPMessage msg = SIPMessage.parse(messageBytes);
//                                if (msg instanceof SipRequest) {
//                                    eventScanner.addEvent(new EventWrapper(EventWrapper.EventType.REQUEST, SipRequestEvent(this, (SipRequest) msg)));
//                                } else if (msg instanceof SipResponse) {
//                                    eventScanner.addEvent(new EventWrapper(EventWrapper.EventType.RESPONSE, SipRequestEvent(this, (SipResponse) msg)));
//                                }
//                            } catch (Exception e) {
//                                eventScanner.addEvent(new EventWrapper(EventWrapper.EventType.ERROR, new java.util.EventObject(e)));
//                            }
//                        }
//                    }
//                } catch (IOException e) {
//                    eventScanner.addEvent(new EventWrapper(EventWrapper.EventType.ERROR, new java.util.EventObject(e)));
//                } finally {
//                    connected = false;
//                    eventScanner.addEvent(new EventWrapper(EventWrapper.EventType.DISCONNECT, new java.util.EventObject(socket.getRemoteSocketAddress())));
//                    try {
//                        socket.close();
//                    } catch (IOException ignored) {
//                    }
//                }
//            }
//
//            void send(byte[] data) throws IOException {
//                synchronized (out) {
//                    out.write(data);
//                    out.flush();
//                }
//            }
//
//            void shutdown() {
//                connected = false;
//                try {
//                    socket.close();
//                } catch (IOException ignored) {
//                }
//            }
//
//            private int indexOfDoubleCRLF(byte[] data) {
//                for (int i = 0; i < data.length - 3; i++) {
//                    if (data[i] == 13 && data[i + 1] == 10 && data[i + 2] == 13 && data[i + 3] == 10) {
//                        return i + 4; // 返回分隔符后位置
//                    }
//                }
//                return -1;
//            }
//        }
//    }
//}
