package secondVersion.sipsim.bak;

import java.util.EventObject;

public class SipResponseEvent extends EventObject {
    private final SipLikeMessage message;

    public SipResponseEvent(Object source, SipLikeMessage message) {
        super(source);
        this.message = message;
    }

    public SipLikeMessage getMessage() { return message; }
}