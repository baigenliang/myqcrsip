package secondVersion.sipsim.bak;


import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import secondVersion.sipsim.bak.EventScannerOld;
import secondVersion.sipsim.bak.SipLikeMessage;
import secondVersion.sipsim.bak.SipRequestEvent;
import secondVersion.sipsim.bak.SipResponseEvent;
import secondVersion.sipsim.core.EventWrapper;
import secondVersion.sipsim.core.EventWrapper.EventType;
import java.net.SocketAddress;

public class SipMessageHandler extends SimpleChannelInboundHandler<SipLikeMessage> {
    private final EventScannerOld scanner;

    public SipMessageHandler(EventScannerOld scanner) { this.scanner = scanner; }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, SipLikeMessage msg) {
//        if (msg.startLine != null && msg.startLine.startsWith("INVITE")) {
//            scanner.addEvent(new EventWrapper(EventType.REQUEST, new SipRequestEvent(this, msg)));
//        } else {
//            scanner.addEvent(new EventWrapper(EventType.RESPONSE, new SipResponseEvent(this, msg)));
//        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        scanner.addEvent(new EventWrapper(EventType.ERROR, new java.util.EventObject(cause)));
        ctx.close();
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        SocketAddress remote = ctx.channel().remoteAddress();
        scanner.addEvent(new EventWrapper(EventType.DISCONNECT, new java.util.EventObject(remote)));
        super.channelInactive(ctx);
    }
}