package secondVersion.sipsim.bak;

import java.nio.charset.Charset;
import java.util.LinkedHashMap;
import java.util.Map;

public class SipLikeMessage {
    public static final Charset GB2312 = Charset.forName("GB2312");
    public static final String CRLF = "\r\n";

    public String startLine;
    public final LinkedHashMap<String, String> headers = new LinkedHashMap<>();
    public String body;

    public SipLikeMessage() {}

    public byte[] toBytes() {
        StringBuilder sb = new StringBuilder();
        sb.append(startLine).append(CRLF);
        for (Map.Entry<String, String> e : headers.entrySet()) {
            sb.append(e.getKey()).append(":").append(e.getValue()).append(CRLF);
        }
        sb.append(CRLF);
        byte[] headerBytes = sb.toString().getBytes(java.nio.charset.StandardCharsets.US_ASCII);
        byte[] bodyBytes = (body == null) ? new byte[0] : body.getBytes(GB2312);
        byte[] out = new byte[headerBytes.length + bodyBytes.length];
        System.arraycopy(headerBytes, 0, out, 0, headerBytes.length);
        System.arraycopy(bodyBytes, 0, out, headerBytes.length, bodyBytes.length);
        return out;
    }

    @Override
    public String toString() {
        try {
            return new String(toBytes(), GB2312);
        } catch (Exception e) {
            return startLine + "\\n(headers...)\\n" + body;
        }
    }
}
