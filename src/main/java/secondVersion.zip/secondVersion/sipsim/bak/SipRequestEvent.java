package secondVersion.sipsim.bak;


import secondVersion.sipsim.common.SIPMessage;

import java.util.EventObject;

public class SipRequestEvent extends EventObject {
    private final SIPMessage message;

    public SipRequestEvent(Object source, SIPMessage message) {
        super(source);
        this.message = message;
    }

    public SIPMessage getMessage() { return message; }
}