package secondVersion.sipsim.netTrans;

import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.Unpooled;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.bytes.ByteArrayEncoder;
import secondVersion.sipsim.bak.SipLikeFrameDecoder;
import secondVersion.sipsim.bak.SipLikeMessage;


public class TcpClient {
    private final String host;
    private final int port;

    public TcpClient(String host, int port) { this.host = host; this.port = port; }

    public void run() throws Exception {
        EventLoopGroup group = new NioEventLoopGroup();
        try {
            Bootstrap b = new Bootstrap();
            b.group(group)
                    .channel(NioSocketChannel.class)
                    .handler(new ChannelInitializer<SocketChannel>() {
                        @Override
                        protected void initChannel(SocketChannel ch) {
                            ChannelPipeline p = ch.pipeline();
                            p.addLast(new SipLikeFrameDecoder());
                            p.addLast(new ByteArrayEncoder());
                            p.addLast(new SimpleChannelInboundHandler<SipLikeMessage>() {
                                @Override
                                protected void channelRead0(ChannelHandlerContext ctx, SipLikeMessage msg) {
                                    System.out.println("TCP Client received reply:\n" + msg);
                                }

                                @Override
                                public void channelActive(ChannelHandlerContext ctx) throws Exception {
                                    String xml = "<?xml version=\"1.0\" encoding=\"GB2312\" standalone=\"yes\"?>\r\n"
                                            + "<request command=\"StartStream\">\r\n"
                                            + "  <parameters>\r\n"
                                            + "    <StreamID>101</StreamID>\r\n"
                                            + "  </parameters>\r\n"
                                            + "</request>";

                                    SipLikeMessage m = new SipLikeMessage();
                                    m.startLine = "INVITE sip:qcr575@device SIP/2.0";
                                    m.headers.put("Via", "SIP/2.0/TCP 127.0.0.1:5060");
                                    m.headers.put("To", "<sip:device2@local>");
                                    m.headers.put("From", "<sip:device1@local>;tag=dev001");
                                    m.headers.put("Max-Forwards", "70");
                                    m.headers.put("Call-ID", "call-1234");
                                    m.headers.put("CSeq", "1 INVITE");
                                    m.headers.put("Content-Type", "RVSS/xml");
                                    m.body = xml;
                                    m.headers.put("Content-Length", String.valueOf(m.body.getBytes(SipLikeMessage.GB2312).length));

                                    ctx.writeAndFlush(Unpooled.wrappedBuffer(m.toBytes()));
                                    System.out.println("TCP Client sent INVITE");
                                }
                            });
                        }
                    });

            ChannelFuture f = b.connect(host, port).sync();
            f.channel().closeFuture().sync();
        } finally {
            group.shutdownGracefully();
        }
    }
}