package secondVersion.sipsim.netTrans;

import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.DatagramPacket;
import io.netty.channel.socket.nio.NioDatagramChannel;
import secondVersion.sipsim.bak.SipRequestEvent;
import secondVersion.sipsim.bak.SipResponseEvent;
import secondVersion.sipsim.bak.EventScannerOld;
import secondVersion.sipsim.core.EventWrapper;
import secondVersion.sipsim.bak.SipLikeMessage;
import secondVersion.sipsim.core.EventWrapper.EventType;

import java.net.InetSocketAddress;

public class UdpServer {
    private final int port;
    private final EventScannerOld scanner;

    public UdpServer(int port, EventScannerOld scanner) { this.port = port; this.scanner = scanner; }

    public void run() throws InterruptedException {
        EventLoopGroup group = new NioEventLoopGroup();
        try {
            Bootstrap b = new Bootstrap();
            b.group(group)
                    .channel(NioDatagramChannel.class)
                    .handler(new SimpleChannelInboundHandler<DatagramPacket>() {
                        @Override
                        protected void channelRead0(ChannelHandlerContext ctx, DatagramPacket packet) throws Exception {
                            ByteBuf buf = packet.content();
                            byte[] arr = new byte[buf.readableBytes()];
                            buf.readBytes(arr);

                            // parse similarly to TCP decoder
                            int headerEnd = -1;
                            for (int i = 0; i < arr.length - 3; i++) {
                                if (arr[i] == 13 && arr[i+1] == 10 && arr[i+2] == 13 && arr[i+3] == 10) { headerEnd = i; break; }
                            }
                            if (headerEnd == -1) return;

                            String header = new String(arr, 0, headerEnd, java.nio.charset.StandardCharsets.US_ASCII);
                            int contentLength = 0;
                            for (String line : header.split("\r\n")) {
                                if (line.toLowerCase().startsWith("content-length:")) {
                                    contentLength = Integer.parseInt(line.substring(line.indexOf(':')+1).trim());
                                }
                            }
                            String body = "";
                            if (contentLength > 0 && arr.length >= headerEnd + 4 + contentLength) {
                                body = new String(arr, headerEnd + 4, contentLength, SipLikeMessage.GB2312);
                            }
                            String[] lines = header.split("\r\n");
                            SipLikeMessage m = new SipLikeMessage();
                            m.startLine = lines[0].trim();
                            for (int i = 1; i < lines.length; i++) {
                                String l = lines[i];
                                int idx = l.indexOf(':');
                                if (idx > 0) m.headers.put(l.substring(0, idx).trim(), l.substring(idx+1).trim());
                            }
                            m.body = body;

                            if (m.startLine.startsWith("INVITE")) {
                                scanner.addEvent(new EventWrapper(EventType.REQUEST, new SipRequestEvent(this, m)));
                            } else {
                                scanner.addEvent(new EventWrapper(EventType.RESPONSE, new SipResponseEvent(this, m)));
                            }
                        }
                    });

            Channel ch = b.bind(new InetSocketAddress(port)).sync().channel();
            System.out.println("UDP Server listening on " + port);
            ch.closeFuture().await();
        } finally {
            group.shutdownGracefully();
        }
    }
}