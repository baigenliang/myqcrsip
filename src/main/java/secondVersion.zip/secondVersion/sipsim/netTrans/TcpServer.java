package secondVersion.sipsim.netTrans;


import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import secondVersion.sipsim.bak.ByteArrayEncoder;
import secondVersion.sipsim.bak.EventScannerOld;
import secondVersion.sipsim.bak.SipLikeFrameDecoder;
import secondVersion.sipsim.bak.SipMessageHandler;

public class TcpServer {
    private final int port;
    private final EventScannerOld scanner;

    public TcpServer(int port, EventScannerOld scanner) { this.port = port; this.scanner = scanner; }

    public void start() throws InterruptedException {
        EventLoopGroup boss = new NioEventLoopGroup(1);
        EventLoopGroup worker = new NioEventLoopGroup();
        try {
            ServerBootstrap b = new ServerBootstrap();
            b.group(boss, worker)
                    .channel(NioServerSocketChannel.class)
                    .childHandler(new ChannelInitializer<SocketChannel>() {
                        @Override
                        protected void initChannel(SocketChannel ch) {
                            ChannelPipeline p = ch.pipeline();
                            p.addLast(new SipLikeFrameDecoder());
                            p.addLast(new ByteArrayEncoder());
                            p.addLast(new SipMessageHandler(scanner));
                        }
                    });

            ChannelFuture f = b.bind(port).sync();
            System.out.println("TCP Server listening on " + port);
            f.channel().closeFuture().sync();
        } finally {
            boss.shutdownGracefully();
            worker.shutdownGracefully();
        }
    }
}
