package secondVersion.sipsim.netTrans;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.Unpooled;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.DatagramPacket;
import io.netty.channel.socket.nio.NioDatagramChannel;
import secondVersion.sipsim.bak.SipLikeMessage;

import java.net.InetSocketAddress;

public class UdpClient {
    private final String host;
    private final int port;

    public UdpClient(String host, int port) { this.host = host; this.port = port; }

    public void run() throws InterruptedException {
        EventLoopGroup group = new NioEventLoopGroup();
        try {
            Bootstrap b = new Bootstrap();
            b.group(group)
                    .channel(NioDatagramChannel.class)
                    .handler(new SimpleChannelInboundHandler<DatagramPacket>() {
                        @Override
                        protected void channelRead0(ChannelHandlerContext ctx, DatagramPacket msg) throws Exception {
                            // ignore responses in demo
                        }
                    });

            Channel ch = b.bind(0).sync().channel();

            String xml = "<?xml version=\"1.0\" encoding=\"GB2312\" standalone=\"yes\"?>\r\n"
                    + "<request command=\"StartStream\">\r\n"
                    + "  <parameters>\r\n"
                    + "    <StreamID>101</StreamID>\r\n"
                    + "  </parameters>\r\n"
                    + "</request>";

            SipLikeMessage m = new SipLikeMessage();
            m.startLine = "INVITE sip:qcr575@device SIP/2.0";
            m.headers.put("Via", "SIP/2.0/UDP 127.0.0.1:5060");
            m.headers.put("To", "<sip:device2@local>");
            m.headers.put("From", "<sip:device1@local>;tag=dev001");
            m.headers.put("Call-ID", "call-udp-1");
            m.headers.put("CSeq", "1 INVITE");
            m.headers.put("Content-Type", "RVSS/xml");
            m.body = xml;
            m.headers.put("Content-Length", String.valueOf(m.body.getBytes(SipLikeMessage.GB2312).length));

            byte[] data = m.toBytes();
            ch.writeAndFlush(new DatagramPacket(Unpooled.wrappedBuffer(data), new InetSocketAddress(host, port))).sync();
            System.out.println("UDP Client sent INVITE");

            Thread.sleep(2000);
        } finally {
            group.shutdownGracefully();
        }
    }
}