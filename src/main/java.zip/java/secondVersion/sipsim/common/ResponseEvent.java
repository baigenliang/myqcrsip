package secondVersion.sipsim.common;

import java.util.EventObject;

public class ResponseEvent extends EventObject {
    private final SipResponse response;

    public ResponseEvent(Object source, SipResponse response) {
        super(source);
        this.response = response;
    }

    public SipResponse getResponse() {
        return response;
    }
}