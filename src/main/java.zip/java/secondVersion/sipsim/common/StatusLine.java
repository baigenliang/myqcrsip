package secondVersion.sipsim.common;



// 响应行
public class StatusLine {
    private String sipVersion; // SIP/2.0
    private int statusCode;    // 200, 404, etc.
    private String reasonPhrase; // OK, Not Found

    public StatusLine(String sipVersion, int statusCode, String reasonPhrase) {
        this.sipVersion = sipVersion;
        this.statusCode = statusCode;
        this.reasonPhrase = reasonPhrase;
    }

    public String getSipVersion() {
        return sipVersion;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public String getReasonPhrase() {
        return reasonPhrase;
    }

    public void setSipVersion(String sipVersion) {
        this.sipVersion = sipVersion;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public void setReasonPhrase(String reasonPhrase) {
        this.reasonPhrase = reasonPhrase;
    }

    /**
     * 序列化为 SIP 协议的状态行
     * 例: SIP/2.0 200 OK
     */
    public String encode() {
        return sipVersion + " " + statusCode + " " + reasonPhrase + "\r\n";
    }
}