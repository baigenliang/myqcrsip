package secondVersion.sipsim.common;

public class TimeoutEvent {
    private final SipProvider source;
    private final String transactionId;

    public TimeoutEvent(SipProvider source, String transactionId) {
        this.source = source;
        this.transactionId = transactionId;
    }

    public SipProvider getSource() { return source; }
    public String getTransactionId() { return transactionId; }
}