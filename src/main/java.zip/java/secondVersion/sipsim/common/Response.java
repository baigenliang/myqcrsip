package secondVersion.sipsim.common;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

public class Response {
    private int statusCode;
    private String reasonPhrase;
    private String body;

    public Response(int statusCode, String reasonPhrase, String body) {
        this.statusCode = statusCode;
        this.reasonPhrase = reasonPhrase;
        this.body = body;
    }

    public int getStatusCode() { return statusCode; }
    public String getReasonPhrase() { return reasonPhrase; }
    public String getBody() { return body; }

    @Override
    public String toString() {
        return "SIP/2.0 " + statusCode + " " + reasonPhrase + "\r\n\r\n" + body;
    }

    public abstract static class SipMessage {
        protected Map<String, String> headers = new LinkedHashMap<>();
        protected byte[] rawContent;

        public String getHeader(String name) {
            return headers.get(name.toLowerCase());
        }

        public byte[] getRawContent() {
            return rawContent;
        }

        public String getBodyAsString() {
            return rawContent == null ? null : new String(rawContent, StandardCharsets.UTF_8);
        }

        public abstract String encode();
    }
}
