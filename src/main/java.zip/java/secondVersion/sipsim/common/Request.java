package secondVersion.sipsim.common;

public class Request {
    private String method;
    private String uri;
    private String body;

    public Request(String method, String uri, String body) {
        this.method = method;
        this.uri = uri;
        this.body = body;
    }

    public String getMethod() { return method; }
    public String getUri() { return uri; }
    public String getBody() { return body; }

    @Override
    public String toString() {
        return method + " " + uri + " SIP/2.0\r\n\r\n" + body;
    }
}
