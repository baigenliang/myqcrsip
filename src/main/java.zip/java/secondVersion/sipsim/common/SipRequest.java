package secondVersion.sipsim.common;

import secondVersion.sipsim.common.RequestLine;
import secondVersion.sipsim.common.Response;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

public class SipRequest extends SIPMessage{

    private RequestLine requestLine;

    public SipRequest(RequestLine requestLine) {
        this.requestLine = requestLine;
    }

    @Override
    public String encode() {
        StringBuilder sb = new StringBuilder();
        sb.append(requestLine.encode()).append("\r\n");
        for (Map.Entry<String, List<String>> e : headers.entrySet()) {
            String key = e.getKey();
            for (String value : e.getValue()) {
                sb.append(key).append(": ").append(value).append("\r\n");
            }
        }
        sb.append("\r\n");
        if (rawContent != null) {
            sb.append(new String(rawContent, StandardCharsets.UTF_8));
        }
        return sb.toString();
    }

//    // build convenience (后续测试可用）
//    public static SipRequest createInvite(String targetUri, String viaHost, String from, String to, String callId, int cseq, String xmlBody) {
//        SipRequest r = new SipRequest();
//        r.startLine = "INVITE " + targetUri + " SIP/2.0";
//        r.headers.put("Via", "SIP/2.0/TCP " + viaHost);
//        r.headers.put("To", to);
//        r.headers.put("From", from);
//        r.headers.put("Max-Forwards", "70");
//        r.headers.put("Call-ID", callId);
//        r.headers.put("CSeq", cseq + " INVITE");
//        r.headers.put("Content-Type", "RVSS/xml");
//        r.body = xmlBody == null ? new byte[0] : xmlBody.getBytes(GB2312);
//        return r;
//    }
}
