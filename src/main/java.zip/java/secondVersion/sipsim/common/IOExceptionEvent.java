package secondVersion.sipsim.common;

public class IOExceptionEvent {
    private final SipProvider source;
    private final Exception exception;

    public IOExceptionEvent(SipProvider source, Exception exception) {
        this.source = source;
        this.exception = exception;
    }

    public SipProvider getSource() { return source; }
    public Exception getException() { return exception; }
}