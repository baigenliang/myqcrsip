package secondVersion.sipsim.common;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public abstract class SIPMessage {
    protected Map<String, List<String>> headers = new LinkedHashMap<>();
    protected byte[] rawContent;

    public abstract String encode();

    public String getHeader(String name) {
        List<String> values = headers.get(name.toLowerCase());
        return (values != null && !values.isEmpty()) ? values.get(0) : null;
    }

    public List<String> getHeaders(String name) {
        return headers.get(name.toLowerCase());
    }

    public void addHeader(String name, String value) {
        String key = name.toLowerCase();
        headers.computeIfAbsent(key, k -> new ArrayList<>()).add(value);
    }

    public byte[] getRawContent() {
        return rawContent;
    }

    public String getBodyAsString() {
        return rawContent != null ? new String(rawContent, StandardCharsets.UTF_8) : null;
    }

    /**
     * 解析 SIP 消息
     */
    public static SIPMessage parse(byte[] data) throws Exception {
        String message = new String(data, StandardCharsets.UTF_8);

        // 找到头和body的分隔符
        int headerEndIdx = message.indexOf("\r\n\r\n");
        if (headerEndIdx == -1) {
            throw new Exception("Invalid SIP message: missing header/body separator");
        }

        String headerPart = message.substring(0, headerEndIdx);
        String bodyPart = message.substring(headerEndIdx + 4); // 跳过 \r\n\r\n

        String[] headerLines = headerPart.split("\r\n");
        if (headerLines.length == 0) {
            throw new Exception("Invalid SIP message: empty headers");
        }

        String firstLine = headerLines[0];
        SIPMessage sipMessage;

        // 判断是请求还是响应
        if (firstLine.startsWith("SIP/")) {
            // Response
            String[] parts = firstLine.split(" ", 3);
            if (parts.length < 3) throw new Exception("Invalid SIP status line");
            StatusLine statusLine = new StatusLine(parts[0], Integer.parseInt(parts[1]), parts[2]);
            SipResponse response = new SipResponse(statusLine);
            sipMessage = response;
        } else {
            // Request
            String[] parts = firstLine.split(" ", 3);
            if (parts.length < 3) throw new Exception("Invalid SIP request line");
            RequestLine requestLine = new RequestLine(parts[0], parts[1], parts[2]);
            SipRequest request = new SipRequest(requestLine);
            sipMessage = request;
        }

        // 解析 Headers
        for (int i = 1; i < headerLines.length; i++) {
            String line = headerLines[i];
            int idx = line.indexOf(":");
            if (idx > 0) {
                String name = line.substring(0, idx).trim();
                String value = line.substring(idx + 1).trim();
                sipMessage.addHeader(name, value);
            }
        }

        // 设置 Body
        if (!bodyPart.isEmpty()) {
            sipMessage.rawContent = bodyPart.getBytes(StandardCharsets.UTF_8);
        }

        return sipMessage;
    }
}