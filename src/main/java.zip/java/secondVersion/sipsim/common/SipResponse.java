package secondVersion.sipsim.common;

import secondVersion.sipsim.common.Response;
import secondVersion.sipsim.common.StatusLine;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

public class SipResponse extends  SIPMessage {

    // convenience build 200 OK (matching CSeq and Call-ID from request)(后续测试可用）
//    public static SipResponse create200OkFrom(SipRequest req) {
//        SipResponse r = new SipResponse();
//        r.startLine = "SIP/2.0 200 OK";
//        // copy headers but remove Max-Forwards and such: keep Via/To/From/Call-ID/CSeq/Content-Type
//        if (req.getHeader("Via") != null) r.headers.put("Via", req.getHeader("Via"));
//        if (req.getHeader("To") != null) r.headers.put("To", req.getHeader("To"));
//        if (req.getHeader("From") != null) r.headers.put("From", req.getHeader("From"));
//        if (req.getHeader("Call-ID") != null) r.headers.put("Call-ID", req.getHeader("Call-ID"));
//        if (req.getHeader("CSeq") != null) r.headers.put("CSeq", req.getHeader("CSeq"));
//        r.headers.put("Content-Type", "RVSS/xml");
//        String body = "<?xml version=\"1.0\" encoding=\"GB2312\" standalone=\"yes\"?>\r\n<response command=\"StartStream\"><result code=\"0\">OK</result></response>";
//        r.body = body.getBytes(GB2312);
//        r.parseStatusLine();
//        return r;
//    }

    private StatusLine statusLine;

    public SipResponse(StatusLine statusLine) {
        this.statusLine = statusLine;
    }

    @Override
    public String encode() {
        StringBuilder sb = new StringBuilder();
        sb.append(statusLine.encode()).append("\r\n");
        for (Map.Entry<String, List<String>> e : headers.entrySet()) {
            String key = e.getKey();
            for (String value : e.getValue()) {
                sb.append(key).append(": ").append(value).append("\r\n");
            }
        }
        sb.append("\r\n");
        if (rawContent != null) {
            sb.append(new String(rawContent, StandardCharsets.UTF_8));
        }
        return sb.toString();
    }
}
