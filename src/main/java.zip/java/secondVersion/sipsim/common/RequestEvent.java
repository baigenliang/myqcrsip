package secondVersion.sipsim.common;

import java.util.EventObject;

public class RequestEvent extends EventObject {

    private final SipRequest request;

    public RequestEvent(Object source, SipRequest request) {
        super(source);
        this.request = request;
    }

    public SipRequest getRequest() {
        return request;
    }
}