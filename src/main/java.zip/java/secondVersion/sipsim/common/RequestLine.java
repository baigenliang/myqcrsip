package secondVersion.sipsim.common;


// 请求行
public class RequestLine {
    private String method;     // INVITE, ACK, BYE, etc.
    private String requestURI; // sip:user@domain
    private String sipVersion; // SIP/2.0

    public RequestLine(String method, String requestURI, String sipVersion) {
        this.method = method;
        this.requestURI = requestURI;
        this.sipVersion = sipVersion;
    }

    public String getMethod() {
        return method;
    }

    public String getRequestURI() {
        return requestURI;
    }

    public String getSipVersion() {
        return sipVersion;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public void setRequestURI(String requestURI) {
        this.requestURI = requestURI;
    }

    public void setSipVersion(String sipVersion) {
        this.sipVersion = sipVersion;
    }

    /**
     * 序列化为 SIP 协议的请求行
     * 例: INVITE sip:bob@biloxi.com SIP/2.0
     */
    public String encode() {
        return method + " " + requestURI + " " + sipVersion + "\r\n";
    }
}

