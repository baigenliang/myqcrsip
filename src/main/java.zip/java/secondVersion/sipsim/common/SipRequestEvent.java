package secondVersion.sipsim.common;


import secondVersion.sipsim.core.SipLikeMessage;

import java.util.EventObject;

public class SipRequestEvent extends EventObject {
    private final Response.SipMessage message;

    public SipRequestEvent(Object source, Response.SipMessage message) {
        super(source);
        this.message = message;
    }

    public Response.SipMessage getMessage() { return message; }
}