package secondVersion.sipsim.common;

import java.util.EventObject;

public interface ISIPProcessorObserver {
    void processRequest(EventObject evt);
    void processResponse(EventObject evt);
    void onTimeout(EventObject evt);
    void onError(Object error);
    void onDisconnect(EventObject evt);
}
