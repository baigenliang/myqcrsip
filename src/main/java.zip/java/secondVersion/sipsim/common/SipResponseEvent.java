package secondVersion.sipsim.common;

import secondVersion.sipsim.core.SipLikeMessage;

import java.util.EventObject;

public class SipResponseEvent extends EventObject {
    private final SipLikeMessage message;

    public SipResponseEvent(Object source, SipLikeMessage message) {
        super(source);
        this.message = message;
    }

    public SipLikeMessage getMessage() { return message; }
}