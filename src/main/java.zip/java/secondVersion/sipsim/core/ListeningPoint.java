package secondVersion.sipsim.core;
/**
 * ListeningPoint 表示一个监听点（IP + Port + Transport）
 */
public class ListeningPoint {
    public enum Transport { UDP, TCP }

    private final String ip;
    private final int port;
    private final Transport transport;

    public ListeningPoint(String ip, int port, Transport transport) {
        if (ip == null) throw new IllegalArgumentException("ip cannot be null");
        this.ip = ip;
        this.port = port;
        this.transport = transport;
    }

    public String getIp() { return ip; }
    public int getPort() { return port; }
    public Transport getTransport() { return transport; }

    public String key() {
        return ip + ":" + port + ":" + transport.name();
    }

    @Override
    public String toString() {
        return "ListeningPoint{" + ip + ":" + port + "," + transport + "}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ListeningPoint)) return false;
        ListeningPoint lp = (ListeningPoint) o;
        return port == lp.port && ip.equals(lp.ip) && transport == lp.transport;
    }

    @Override
    public int hashCode() {
        return key().hashCode();
    }
}