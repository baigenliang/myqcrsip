package secondVersion.sipsim.core;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;

import java.nio.charset.Charset;
import java.util.List;

public class SipLikeFrameDecoder extends ByteToMessageDecoder {
    private static final byte CR = 13;
    private static final byte LF = 10;
    private static final Charset ASCII = Charset.forName("US-ASCII");

    @Override
    protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {
        int readable = in.readableBytes();
        if (readable == 0) return;

        int headerEnd = indexOfHeaderEnd(in);
        if (headerEnd == -1) return; // header not complete

        int headerLen = headerEnd - in.readerIndex();
        byte[] headerBytes = new byte[headerLen];
        in.getBytes(in.readerIndex(), headerBytes);
        String headerStr = new String(headerBytes, ASCII);

        int contentLength = parseContentLength(headerStr);
        int totalNeeded = headerLen + 4 + contentLength;
        if (in.readableBytes() < totalNeeded) return; // body not complete

        byte[] total = new byte[totalNeeded];
        in.readBytes(total);

        String headerPart = new String(total, 0, headerLen, ASCII);
        String bodyPart = "";
        if (contentLength > 0) {
            bodyPart = new String(total, headerLen + 4, contentLength, SipLikeMessage.GB2312);
        }

        SipLikeMessage msg = parseMessage(headerPart, bodyPart);
        out.add(msg);
    }

    private int indexOfHeaderEnd(ByteBuf buf) {
        int readable = buf.readableBytes();
        int offset = buf.readerIndex();
        for (int i = offset; i < offset + readable - 3; i++) {
            if (buf.getByte(i) == CR && buf.getByte(i+1) == LF && buf.getByte(i+2) == CR && buf.getByte(i+3) == LF) {
                return i;
            }
        }
        return -1;
    }

    private int parseContentLength(String headerStr) {
        String[] lines = headerStr.split("\r\n");
        for (String l : lines) {
            if (l.toLowerCase().startsWith("content-length:")) {
                try { return Integer.parseInt(l.substring(l.indexOf(':') + 1).trim()); } catch (Exception e) { return 0; }
            }
        }
        return 0;
    }

    private SipLikeMessage parseMessage(String headerPart, String body) {
        String[] lines = headerPart.split("\r\n");
        SipLikeMessage m = new SipLikeMessage();
        m.startLine = lines[0].trim();
        for (int i = 1; i < lines.length; i++) {
            String line = lines[i];
            int idx = line.indexOf(':');
            if (idx > 0) {
                String k = line.substring(0, idx).trim();
                String v = line.substring(idx + 1).trim();
                m.headers.put(k, v);
            }
        }
        m.body = body;
        return m;
    }
}