//package secondVersion.sipsim.core;
//
//import secondVersion.sipsim.common.*;
//
//import java.io.IOException;
//import java.nio.charset.StandardCharsets;
//import java.util.*;
//import java.util.concurrent.ConcurrentHashMap;
//
//
///**
// * SipProviderImpl 负责：
// * - 管理监听点（add/remove/get/getAll）
// * - 管理 SipListeners
// * - 提供 sendRequest/sendResponse（转给 TransportManager）
// * - dispatchIncoming(Event) 将 RequestEvent/ResponseEvent 转给 listeners
// */
//public class SipProviderImpl extends  SipProvider{
////    private final TransportManager transport;
////    private final BlockingQueue<EventObject> eventQueue;
////    private final Map<String, ListeningPoint> lpMap = new LinkedHashMap<>();
////    private final List<SipListener> listeners = Collections.synchronizedList(new ArrayList<>());
////
////    public SipProviderImpl(TransportManager transport, BlockingQueue<EventObject> eventQueue) {
////        this.transport = transport;
////        this.eventQueue = eventQueue;
////    }
////
////    // ListeningPoint management
////    public void addListeningPoint(ListeningPoint lp) throws IOException {
////        String key = lp.key();
////        if (lpMap.containsKey(key)) return;
////        lpMap.put(key, lp);
////        transport.addListeningPoint(lp);
////    }
////
////    public void removeListeningPoint(ListeningPoint lp) {
////        String key = lp.key();
////        if (!lpMap.containsKey(key)) return;
////        lpMap.remove(key);
////        transport.removeListeningPoint(lp);
////    }
////
////    // get listening point by transport (returns first match), or null
////    public ListeningPoint getListeningPoint(ListeningPoint.Transport transportType) {
////        for (ListeningPoint lp : lpMap.values()) {
////            if (lp.getTransport() == transportType) return lp;
////        }
////        return null;
////    }
////
////    // get by ip/port/transport
////    public ListeningPoint getListeningPoint(String ip, int port, ListeningPoint.Transport transportType) {
////        return lpMap.get(ip + ":" + port + ":" + transportType.name());
////    }
////
////    public ListeningPoint[] getListeningPoints() {
////        return lpMap.values().toArray(new ListeningPoint[0]);
////    }
////
////    // SipListener management
////    public void addSipListener(SipListener l) { listeners.add(l); }
////    public void removeSipListener(SipListener l) { listeners.remove(l); }
//
//    // dispatch incoming event (called by EventScanner)
////    public void dispatchIncoming(EventObject ev) {
////        if (ev instanceof RequestEvent) {
////            RequestEvent re = (RequestEvent) ev;
////            // notify listeners about incoming request
////            for (SipListener l : listeners) {
////                try { l.processRequest(re); } catch (Throwable t) { t.printStackTrace(); }
////            }
////            // optionally: automatically send 200 OK (you can remove or make configurable)
////            try {
////                SipResponse resp = SipResponse.create200OkFrom(re.getRequest());
////                // find via header to determine destination; fallback to localhost: use default
////                String via = re.getRequest().getHeader("Via");
////                InetSocketAddress dst = new InetSocketAddress("127.0.0.1", 5060);
////                if (via != null) {
////                    String after = via.substring(via.lastIndexOf(' ') + 1).trim();
////                    String[] hp = after.split(":");
////                    if (hp.length == 2) dst = new InetSocketAddress(hp[0], Integer.parseInt(hp[1]));
////                }
////                // send via UDP by default
////                transport.sendUdp(dst.getHostString(), dst.getPort(), resp.toBytes());
////            } catch (Exception e) {
////                e.printStackTrace();
////            }
////        } else if (ev instanceof ResponseEvent) {
////            ResponseEvent re = (ResponseEvent) ev;
////            for (SipListener l : listeners) {
////                try { l.processResponse(re); } catch (Throwable t) { t.printStackTrace(); }
////            }
////        } else {
////            // ignore or extend for timeout/error events
////        }
////    }
////
////    // business API to send request/response
////    public void sendRequest(SipRequest req, ListeningPoint.Transport transportProto, String dstHost, int dstPort) throws IOException {
////        byte[] data = req.toBytes();
////        if (transportProto == ListeningPoint.Transport.UDP) transport.sendUdp(dstHost, dstPort, data);
////        else transport.sendTcp(dstHost, dstPort, data);
////    }
////
////    public void sendResponse(SipResponse resp, ListeningPoint.Transport transportProto, String dstHost, int dstPort) throws IOException {
////        byte[] data = resp.toBytes();
////        if (transportProto == ListeningPoint.Transport.UDP) transport.sendUdp(dstHost, dstPort, data);
////        else transport.sendTcp(dstHost, dstPort, data);
////    }
//
//    private List<SipListener> listeners = new ArrayList<>();
//    private Map<String, ListeningPoint> listeningPoints = new ConcurrentHashMap<>();
//    private TransportManager transportManager;
//
//    public SipProviderImpl() {
//        this.transportManager = new TransportManager(this);
//    }
//
//    public void addListeningPoint(ListeningPoint lp) {
//        listeningPoints.put(lp.getIp() + ":" + lp.getPort(), lp);
//    }
//
//    public ListeningPoint getListeningPoint(String ip, int port) {
//        return listeningPoints.get(ip + ":" + port);
//    }
//
//    public Collection<ListeningPoint> getListeningPoints() {
//        return listeningPoints.values();
//    }
//
//    public void addSipListener(SipListener listener) {
//        listeners.add(listener);
//    }
//
//    public void dispatchIncoming(Object event) {
//        for (SipListener listener : listeners) {
//            if (event instanceof RequestEvent) {
//                listener.processRequest((RequestEvent) event);
//            } else if (event instanceof ResponseEvent) {
//                listener.processResponse((ResponseEvent) event);
//            }
//        }
//    }
//
//    public void sendRequest(SipRequest request, String host, int port) throws IOException {
//        byte[] data = request.encode().getBytes(StandardCharsets.UTF_8);
//        transportManager.sendBytes(host, port, data);
//    }
//
//    public void sendResponse(SipResponse response, String host, int port) throws IOException {
//        byte[] data = response.encode().getBytes(StandardCharsets.UTF_8);
//        transportManager.sendBytes(host, port, data);
//    }
//}

import secondVersion.sipsim.common.SIPMessage;
import secondVersion.sipsim.common.SipProvider;
import secondVersion.sipsim.common.SipRequest;
import secondVersion.sipsim.common.SipResponse;
import secondVersion.sipsim.core.EventScanner;
import secondVersion.sipsim.common.*;
import secondVersion.sipsim.core.EventWrapper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SipProviderImpl implements SipProvider {

    private final Map<String, ListeningPoint> listeningPoints = new HashMap<>();
    private final TransportManager transportManager;
    private final EventScanner eventScanner;

    public SipProviderImpl(EventScanner eventScanner) {
        this.eventScanner = eventScanner;
        this.transportManager = new TransportManager(eventScanner);
    }

    @Override
    public void addListeningPoint(String ip, int port) throws IOException {
        String key = key(ip, port);
        if (listeningPoints.containsKey(key)) {
            return;
        }
        transportManager.addListeningPoint(ip, port);
        listeningPoints.put(key, new ListeningPoint(ip, port));
    }

    @Override
    public void removeListeningPoint(String ip, int port) {
        String key = key(ip, port);
        listeningPoints.remove(key);
        transportManager.removeListeningPoint(ip, port);
    }

    @Override
    public ListeningPoint getListeningPoint(String ip, int port) {
        return listeningPoints.get(key(ip, port));
    }

    @Override
    public List<ListeningPoint> getListeningPoints() {
        return new ArrayList<>(listeningPoints.values());
    }

    @Override
    public void sendRequest(String ip, int port, SipRequest request) throws IOException {
        byte[] data = request.encode().getBytes();
        transportManager.sendMessage(ip, port, data);
    }

    @Override
    public void sendResponse(String ip, int port, SipResponse response) throws IOException {
        byte[] data = response.encode().getBytes();
        transportManager.sendMessage(ip, port, data);
    }

    @Override
    public void dispatchIncoming(SIPMessage message) {
        if (message instanceof SipRequest) {
            eventScanner.addEvent(new EventWrapper(EventType.REQUEST, new SipRequestEvent(this, (SipRequest) message)));
        } else if (message instanceof SipResponse) {
            eventScanner.addEvent(new EventWrapper(EventType.RESPONSE, new SipResponseEvent(this, (SipResponse) message)));
        } else {
            eventScanner.addEvent(new EventWrapper(EventType.ERROR, new java.util.EventObject(new IllegalArgumentException("Unknown SIPMessage type"))));
        }
    }

    private String key(String ip, int port) {
        return ip + ":" + port;
    }
}