package secondVersion.sipsim.core;


import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class EventScannerOld implements Runnable {
    private final BlockingQueue<EventWrapper> queue = new LinkedBlockingQueue<>();
    private volatile boolean running = true;
    private final SIPProcessorObserver observer;

    public EventScannerOld(SIPProcessorObserver observer) { this.observer = observer; }

    public void addEvent(EventWrapper ev) { queue.offer(ev); }

    public void stop() { running = false; }

    @Override
    public void run() {
        while (running) {
            try {
                EventWrapper ev = queue.take();
                dispatch(ev);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            } catch (Throwable t) {
                observer.onError(t);
            }
        }
    }

    private void dispatch(EventWrapper ev) {
        switch (ev.getEventType()) {
            case REQUEST:
                observer.processRequest(ev.getEvent());
                break;
            case RESPONSE:
                observer.processResponse(ev.getEvent());
                break;
            case TIMEOUT:
                observer.onTimeout(ev.getEvent());
                break;
            case ERROR:
                observer.onError(ev.getEvent());
                break;
            case DISCONNECT:
                observer.onDisconnect(ev.getEvent());
                break;
        }
    }


}