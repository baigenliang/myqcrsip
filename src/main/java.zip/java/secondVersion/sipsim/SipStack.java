package secondVersion.sipsim;

import java.util.ArrayList;
import java.util.List;

public class SipStack {
//    private final List<ListeningPoint> listeningPoints = new ArrayList<>();
//
//    public ListeningPoint createListeningPoint(String ip, int port, String transport) {
//        ListeningPoint lp = new ListeningPoint(ip, port, transport);
//        listeningPoints.add(lp);
//        return lp;
//    }
//
//    public SipProvider createSipProvider(ListeningPoint lp) {
//        return new SipProvider(lp);
//    }
}
