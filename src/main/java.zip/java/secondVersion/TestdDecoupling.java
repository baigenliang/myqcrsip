package secondVersion;

import secondVersion.sipsim.common.*;
import secondVersion.sipsim.core.*;

import java.util.EventObject;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class TestdDecoupling {
    public static void main(String[] args) throws Exception {
//        SIPProcessorObserver observer = new SIPProcessorObserver();
//        EventScannerOld scanner = new EventScannerOld(observer);
//        Thread scannerThread = new Thread(scanner, "EventScannerOld-Thread");
//        scannerThread.start();
//
//        // Start TCP Server
//        TcpServer tcpServer = new TcpServer(5060, scanner);
//        new Thread(() -> {
//            try { tcpServer.start(); } catch (InterruptedException e) { e.printStackTrace(); }
//        }, "TcpServer-Thread").start();
//
//        // Start UDP Server
//        UdpServer udpServer = new UdpServer(5060, scanner);
//        new Thread(() -> {
//            try { udpServer.run(); } catch (InterruptedException e) { e.printStackTrace(); }
//        }, "UdpServer-Thread").start();
//
//        // wait a bit then start clients
//        Thread.sleep(1200);
//
//        // Start TCP client to send an INVITE
//        new Thread(() -> {
//            try { new TcpClient("127.0.0.1", 5060).run(); } catch (Exception e) { e.printStackTrace(); }
//        }, "TcpClient-Thread").start();
//
//        // Start UDP client
//        new Thread(() -> {
//            try { new UdpClient("127.0.0.1", 5060).run(); } catch (Exception e) { e.printStackTrace(); }
//        }, "UdpClient-UDP-Thread").start();
//
//        // allow demo to run for a while
//        Thread.sleep(8000);
//        scanner.stop();
//        System.out.println("Demo finished.");
//    }

        // 创建 ListeningPoint
//        ListeningPoint lp = new ListeningPoint("127.0.0.1", 5060, "UDP");
//
//        // 创建 Provider
//        SipProviderImpl provider = new SipProviderImpl(lp);
//
//        // 添加业务层监听器
//        provider.addSipListener(new SipListener() {
//            @Override
//            public void processRequest(String request) {
//                System.out.println("收到请求:\n" + request);
//            }
//
//            @Override
//            public void processResponse(String response) {
//                System.out.println("收到响应:\n" + response);
//            }
//        });
//
//        // 创建 EventScanner
//        EventScanner scanner = new EventScanner(provider);
//        new Thread(scanner, "EventScanner").start();
//
//        // 启动 TransportManager
//        TransportManager tm = new TransportManager(scanner);
//        tm.startUdpListener(lp.getIp(), lp.getPort());
//
//        // 模拟发包
//        Thread.sleep(2000);
//        String testMsg = "INVITE sip:user@example.com SIP/2.0\r\nVia: SIP/2.0/UDP 127.0.0.1:5060\r\n\r\n";
//        tm.sendUdpMessage("127.0.0.1", 5060, testMsg);
//        BlockingQueue<EventObject> queue = new LinkedBlockingQueue<>();
//        TransportManager transport = new TransportManager(queue);
//        // start listeners on localhost:5060 (both UDP and TCP)
//        transport.startListeners("127.0.0.1", 5060);
//
//        SipProviderImpl provider = new SipProviderImpl(transport, queue);
//
//        // event scanner -> provider dispatch
//        EventScanner scanner = new EventScanner(queue, provider);
//        Thread scannerThread = new Thread(scanner, "EventScanner");
//        scannerThread.start();
//
//        // register a sample business listener
//        provider.addSipListener(new SipListener() {
//            @Override
//            public void processRequest(RequestEvent requestEvent) {
//                System.out.println("== BUSINESS: processRequest ==");
//                SipRequest r = requestEvent.getRequest();
//                System.out.println("Method: " + r.getMethod());
//                System.out.println("Call-ID: " + r.getHeader("Call-ID"));
//                System.out.println("CSeq: " + r.getHeader("CSeq"));
//                System.out.println("Body: " + r.getRawContentAsString());
//            }
//
//            @Override
//            public void processResponse(ResponseEvent responseEvent) {
//                System.out.println("== BUSINESS: processResponse ==");
//                SipResponse resp = responseEvent.getResponse();
//                System.out.println("Status: " + resp.getStatusCode() + " " + resp.getReasonPhrase());
//                System.out.println("Call-ID: " + resp.getHeader("Call-ID"));
//                System.out.println("CSeq: " + resp.getHeader("CSeq"));
//                System.out.println("Body: " + resp.getRawContentAsString());
//            }
//        });
//
//        // wait a bit for listeners up
//        Thread.sleep(800);
//
//        // build a sample INVITE and send via UDP and TCP
//        String xml = "<?xml version=\"1.0\" encoding=\"GB2312\" standalone=\"yes\"?>\r\n" +
//                "<request command=\"StartStream\">\r\n" +
//                "  <parameters><StreamID>101</StreamID></parameters>\r\n" +
//                "</request>";
//
//        SipRequest invite = SipRequest.createInvite("sip:qcr575@127.0.0.1", "127.0.0.1:5060",
//                "<sip:client@127.0.0.1>;tag=abc", "<sip:server@127.0.0.1>", "call-001", 1, xml);
//
//        // send via UDP
//        provider.sendRequest(invite, "UDP", "127.0.0.1", 5060);
//        System.out.println("Sent INVITE via UDP");
//
//        // send via TCP
//        provider.sendRequest(invite, "TCP", "127.0.0.1", 5060);
//        System.out.println("Sent INVITE via TCP");
//
//        // wait to observe events
//        Thread.sleep(3000);
//
//        // stop transport and scanner
//        scanner.stop();
//        transport.stop();
//        System.out.println("Demo finished.");

    }
}